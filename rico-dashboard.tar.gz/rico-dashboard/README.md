# TRAJANUS COMMAND CENTER - Rico Operations Dashboard

## Quick Start

```bash
cd rico-dashboard
chmod +x deploy.sh
./deploy.sh
```

Or manually:
```bash
npm install
cp .env.example .env   # Edit with your tokens
node server.js
```

Dashboard: `http://YOUR_VPS_IP:3000`

## For Rico (ClawdBot Integration)

Copy `rico-dashboard-api.js` and `clawdbot-bridge.js` to ClawdBot's directory.

```javascript
// In ClawdBot's code:
const rico = require('./rico-dashboard-api');

// Post morning briefing
await rico.postBriefing('Good morning Bill!', 'Daily Briefing', [
  { title: 'Overnight Work', content: 'Completed X, Y, Z...' },
  { title: 'Today\'s Plan', content: 'Working on A, B, C...' }
]);

// Update project progress
await rico.updateProject('cmd-center', 'Command Center', 72, 'active');

// Log activity
await rico.log('commit', 'Pushed 3 commits to main');

// Update status
await rico.setStatus('Building login page');

// Send chat message
await rico.sendMessage('Task complete.');

// Create task
await rico.createTask('Implement API endpoint', 'high');

// Push notification
await rico.notify('Build Done', 'v1.0 deployed', 'success');
```

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET/POST | /api/status | Rico's current status |
| GET/POST | /api/briefing | Morning briefing |
| GET/POST | /api/projects | Project list & progress |
| GET/POST | /api/tasks | Task queue |
| GET/POST | /api/activity | Activity log |
| GET/POST | /api/messages | Chat messages |
| POST | /api/telegram/send | Send msg via Telegram |
| POST | /api/notifications | Push toast notification |
| GET | /api/git/log | Recent git commits |
| GET | /api/dashboard | Full dashboard state |
| GET | /api/health | Health check |

## AWS Security Group

Open port 3000 in your EC2 security group:
- Type: Custom TCP
- Port: 3000
- Source: Your IP (or 0.0.0.0/0 for anywhere)

## Run as Background Service

```bash
# Option 1: nohup
nohup node server.js > dashboard.log 2>&1 &

# Option 2: PM2 (recommended)
npm install -g pm2
pm2 start server.js --name rico-dashboard
pm2 save
pm2 startup
```
