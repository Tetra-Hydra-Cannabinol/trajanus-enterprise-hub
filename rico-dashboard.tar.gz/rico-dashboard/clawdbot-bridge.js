/**
 * CLAWDBOT BRIDGE
 * Add this to ClawdBot to forward Telegram messages to the dashboard.
 *
 * Usage in ClawdBot's index.js:
 *
 *   const bridge = require('./clawdbot-bridge');
 *
 *   // When Rico receives a message from Bill via Telegram:
 *   bridge.forwardIncoming(messageText);
 *
 *   // When Rico sends a response via Telegram:
 *   bridge.forwardOutgoing(responseText);
 *
 *   // When Rico starts processing:
 *   bridge.setStatus('Processing Bill\'s request...');
 *
 *   // When Rico finishes:
 *   bridge.setStatus('Awaiting orders', true);
 */

const rico = require('./rico-dashboard-api');

module.exports = {

  /** Forward an incoming message (from Bill) to the dashboard */
  forwardIncoming(text) {
    return rico.sendMessage(`[Telegram] Bill: ${text}`).catch(() => {});
  },

  /** Forward an outgoing response (from Rico) to the dashboard */
  forwardOutgoing(text) {
    return rico.sendMessage(text).catch(() => {});
  },

  /** Update Rico's status on the dashboard */
  setStatus(task, online = true) {
    return rico.setStatus(task, online).catch(() => {});
  },

  /** Log an activity from ClawdBot */
  log(message, type = 'chat') {
    return rico.log(type, message).catch(() => {});
  }
};
