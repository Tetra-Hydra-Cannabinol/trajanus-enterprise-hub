/**
 * TRAJANUS COMMAND CENTER - Rico Operations Dashboard
 * Backend Server - Express + Socket.io + Telegram Bridge
 */

require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const fs = require('fs');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

const PORT = process.env.DASHBOARD_PORT || 3000;
const DATA_DIR = path.join(__dirname, 'data');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

// Middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// ============================================================
// DATA PERSISTENCE - Simple JSON file storage
// ============================================================

function loadData(filename, defaultVal = null) {
  const filepath = path.join(DATA_DIR, filename);
  try {
    if (fs.existsSync(filepath)) {
      return JSON.parse(fs.readFileSync(filepath, 'utf-8'));
    }
  } catch (e) {
    console.error(`Error loading ${filename}:`, e.message);
  }
  return defaultVal;
}

function saveData(filename, data) {
  const filepath = path.join(DATA_DIR, filename);
  fs.writeFileSync(filepath, JSON.stringify(data, null, 2));
}

// Initialize dashboard state
let dashboardState = {
  status: loadData('status.json', {
    online: true,
    startedAt: new Date().toISOString(),
    lastActivity: new Date().toISOString(),
    currentTask: 'Awaiting orders',
    model: 'claude-sonnet-4-5',
    version: '1.0.0'
  }),
  briefing: loadData('briefing.json', {
    date: null,
    title: 'No briefing yet',
    content: 'Rico has not posted a morning briefing yet. Briefings appear here automatically.',
    sections: []
  }),
  projects: loadData('projects.json', []),
  tasks: loadData('tasks.json', []),
  activity: loadData('activity.json', []),
  messages: loadData('messages.json', []),
  notifications: loadData('notifications.json', [])
};

function logActivity(type, message, meta = {}) {
  const entry = {
    id: `act-${Date.now()}`,
    timestamp: new Date().toISOString(),
    type,
    message,
    ...meta
  };
  dashboardState.activity.unshift(entry);
  if (dashboardState.activity.length > 500) dashboardState.activity = dashboardState.activity.slice(0, 500);
  saveData('activity.json', dashboardState.activity);
  io.emit('activity', entry);
  return entry;
}

// ============================================================
// TELEGRAM BRIDGE
// ============================================================

let telegramBot = null;
const TELEGRAM_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const TELEGRAM_CHAT_ID = process.env.TELEGRAM_CHAT_ID;

if (TELEGRAM_TOKEN) {
  try {
    const TelegramBot = require('node-telegram-bot-api');
    // Use polling: false - we won't poll (ClawdBot does that)
    // We only use this for SENDING messages
    telegramBot = new TelegramBot(TELEGRAM_TOKEN, { polling: false });
    console.log('[TELEGRAM] Bot initialized (send-only mode)');
  } catch (e) {
    console.log('[TELEGRAM] Not configured:', e.message);
  }
}

// ============================================================
// API ROUTES - Rico pushes data through these
// ============================================================

// --- STATUS ---
app.post('/api/status', (req, res) => {
  const { online, currentTask, model, custom } = req.body;
  if (online !== undefined) dashboardState.status.online = online;
  if (currentTask) dashboardState.status.currentTask = currentTask;
  if (model) dashboardState.status.model = model;
  if (custom) Object.assign(dashboardState.status, custom);
  dashboardState.status.lastActivity = new Date().toISOString();
  saveData('status.json', dashboardState.status);
  io.emit('status', dashboardState.status);
  logActivity('system', `Status updated: ${currentTask || 'status change'}`);
  res.json({ ok: true, status: dashboardState.status });
});

app.get('/api/status', (req, res) => {
  res.json(dashboardState.status);
});

// --- MORNING BRIEFING ---
app.post('/api/briefing', (req, res) => {
  const { title, content, sections } = req.body;
  dashboardState.briefing = {
    date: new Date().toISOString(),
    title: title || 'Morning Briefing',
    content: content || '',
    sections: sections || []
  };
  saveData('briefing.json', dashboardState.briefing);
  io.emit('briefing', dashboardState.briefing);
  logActivity('briefing', `New briefing posted: ${title || 'Morning Briefing'}`);
  res.json({ ok: true, briefing: dashboardState.briefing });
});

app.get('/api/briefing', (req, res) => {
  res.json(dashboardState.briefing);
});

// --- PROJECTS ---
app.post('/api/projects', (req, res) => {
  const project = req.body;
  project.id = project.id || `proj-${Date.now()}`;
  project.updatedAt = new Date().toISOString();
  project.createdAt = project.createdAt || project.updatedAt;
  
  const idx = dashboardState.projects.findIndex(p => p.id === project.id);
  if (idx >= 0) {
    dashboardState.projects[idx] = { ...dashboardState.projects[idx], ...project };
  } else {
    dashboardState.projects.push(project);
  }
  saveData('projects.json', dashboardState.projects);
  io.emit('projects', dashboardState.projects);
  logActivity('project', `Project updated: ${project.name || project.id}`);
  res.json({ ok: true, projects: dashboardState.projects });
});

app.get('/api/projects', (req, res) => {
  res.json(dashboardState.projects);
});

app.delete('/api/projects/:id', (req, res) => {
  dashboardState.projects = dashboardState.projects.filter(p => p.id !== req.params.id);
  saveData('projects.json', dashboardState.projects);
  io.emit('projects', dashboardState.projects);
  res.json({ ok: true });
});

// --- TASKS ---
app.post('/api/tasks', (req, res) => {
  const task = req.body;
  task.id = task.id || `task-${Date.now()}`;
  task.updatedAt = new Date().toISOString();
  task.createdAt = task.createdAt || task.updatedAt;
  task.status = task.status || 'pending';
  task.priority = task.priority || 'medium';
  
  const idx = dashboardState.tasks.findIndex(t => t.id === task.id);
  if (idx >= 0) {
    dashboardState.tasks[idx] = { ...dashboardState.tasks[idx], ...task };
  } else {
    dashboardState.tasks.push(task);
  }
  saveData('tasks.json', dashboardState.tasks);
  io.emit('tasks', dashboardState.tasks);
  logActivity('task', `Task ${idx >= 0 ? 'updated' : 'created'}: ${task.title || task.id}`);
  res.json({ ok: true, tasks: dashboardState.tasks });
});

app.get('/api/tasks', (req, res) => {
  res.json(dashboardState.tasks);
});

app.delete('/api/tasks/:id', (req, res) => {
  dashboardState.tasks = dashboardState.tasks.filter(t => t.id !== req.params.id);
  saveData('tasks.json', dashboardState.tasks);
  io.emit('tasks', dashboardState.tasks);
  res.json({ ok: true });
});

// --- ACTIVITY LOG ---
app.post('/api/activity', (req, res) => {
  const { type, message, meta } = req.body;
  const entry = logActivity(type || 'info', message, meta || {});
  res.json({ ok: true, entry });
});

app.get('/api/activity', (req, res) => {
  const limit = parseInt(req.query.limit) || 50;
  res.json(dashboardState.activity.slice(0, limit));
});

// --- MESSAGES (Dashboard Chat) ---
app.post('/api/messages', (req, res) => {
  const { from, content, source } = req.body;
  const msg = {
    id: `msg-${Date.now()}`,
    timestamp: new Date().toISOString(),
    from: from || 'system',
    content,
    source: source || 'dashboard'
  };
  dashboardState.messages.push(msg);
  if (dashboardState.messages.length > 1000) {
    dashboardState.messages = dashboardState.messages.slice(-1000);
  }
  saveData('messages.json', dashboardState.messages);
  io.emit('message', msg);
  res.json({ ok: true, message: msg });
});

app.get('/api/messages', (req, res) => {
  const limit = parseInt(req.query.limit) || 100;
  res.json(dashboardState.messages.slice(-limit));
});

// --- SEND TO TELEGRAM ---
app.post('/api/telegram/send', async (req, res) => {
  const { text } = req.body;
  if (!telegramBot || !TELEGRAM_CHAT_ID) {
    return res.status(400).json({ ok: false, error: 'Telegram not configured' });
  }
  try {
    await telegramBot.sendMessage(TELEGRAM_CHAT_ID, text);
    // Log as a message from Bill
    const msg = {
      id: `msg-${Date.now()}`,
      timestamp: new Date().toISOString(),
      from: 'bill',
      content: text,
      source: 'dashboard-to-telegram'
    };
    dashboardState.messages.push(msg);
    saveData('messages.json', dashboardState.messages);
    io.emit('message', msg);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

// --- NOTIFICATIONS ---
app.post('/api/notifications', (req, res) => {
  const notif = {
    id: `notif-${Date.now()}`,
    timestamp: new Date().toISOString(),
    title: req.body.title,
    message: req.body.message,
    type: req.body.type || 'info',
    read: false
  };
  dashboardState.notifications.unshift(notif);
  if (dashboardState.notifications.length > 100) {
    dashboardState.notifications = dashboardState.notifications.slice(0, 100);
  }
  saveData('notifications.json', dashboardState.notifications);
  io.emit('notification', notif);
  res.json({ ok: true, notification: notif });
});

app.get('/api/notifications', (req, res) => {
  res.json(dashboardState.notifications);
});

// --- FULL DASHBOARD STATE ---
app.get('/api/dashboard', (req, res) => {
  res.json(dashboardState);
});

// --- GIT LOG (reads from repo if available) ---
app.get('/api/git/log', (req, res) => {
  const repoPath = process.env.REPO_PATH || path.join(require('os').homedir(), 'trajanus-enterprise-hub');
  const { execSync } = require('child_process');
  try {
    const log = execSync(
      `cd "${repoPath}" && git log --oneline --no-decorate -20 2>/dev/null`,
      { encoding: 'utf-8', timeout: 5000 }
    ).trim().split('\n').map(line => {
      const [hash, ...rest] = line.split(' ');
      return { hash, message: rest.join(' ') };
    });
    res.json(log);
  } catch (e) {
    res.json([]);
  }
});

// --- HEALTH CHECK ---
app.get('/api/health', (req, res) => {
  res.json({
    ok: true,
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
    version: '1.0.0'
  });
});

// ============================================================
// SOCKET.IO - Real-time connection
// ============================================================

io.on('connection', (socket) => {
  console.log(`[WS] Client connected: ${socket.id}`);
  // Send full state on connect
  socket.emit('init', dashboardState);

  socket.on('send_message', (data) => {
    const msg = {
      id: `msg-${Date.now()}`,
      timestamp: new Date().toISOString(),
      from: data.from || 'bill',
      content: data.content,
      source: 'dashboard'
    };
    dashboardState.messages.push(msg);
    saveData('messages.json', dashboardState.messages);
    io.emit('message', msg);

    // Also forward to Telegram if configured
    if (telegramBot && TELEGRAM_CHAT_ID) {
      telegramBot.sendMessage(TELEGRAM_CHAT_ID, `[Dashboard] ${data.content}`).catch(() => {});
    }
  });

  socket.on('disconnect', () => {
    console.log(`[WS] Client disconnected: ${socket.id}`);
  });
});

// ============================================================
// START SERVER
// ============================================================

server.listen(PORT, '0.0.0.0', () => {
  console.log('');
  console.log('╔══════════════════════════════════════════════╗');
  console.log('║   TRAJANUS COMMAND CENTER - Dashboard v1.0   ║');
  console.log('╠══════════════════════════════════════════════╣');
  console.log(`║   Running on port ${PORT}                        ║`);
  console.log(`║   http://localhost:${PORT}                       ║`);
  console.log('║   Telegram: ' + (telegramBot ? 'Connected ✓' : 'Not configured') + '                    ║');
  console.log('╚══════════════════════════════════════════════╝');
  console.log('');

  // Mark Rico as online
  dashboardState.status.online = true;
  dashboardState.status.startedAt = new Date().toISOString();
  saveData('status.json', dashboardState.status);
  logActivity('system', 'Command Center Dashboard started');
});
