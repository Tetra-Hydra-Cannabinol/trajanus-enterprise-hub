/**
 * RICO DASHBOARD API
 * Drop-in module for Rico (ClawdBot) to push data to the Command Dashboard.
 *
 * Usage:
 *   const rico = require('./rico-dashboard-api');
 *
 *   // Post morning briefing
 *   rico.postBriefing('Good morning, Bill!', 'Daily Briefing', [
 *     { title: 'Overnight Progress', content: 'Completed feature X...' },
 *     { title: 'Today\'s Plan', content: 'Working on Y...' }
 *   ]);
 *
 *   // Update project progress
 *   rico.updateProject('cmd-center', 'Command Center', 72, 'active', 'Building dashboard API');
 *
 *   // Log activity
 *   rico.log('commit', 'Pushed 3 commits to main branch');
 *
 *   // Update status
 *   rico.setStatus('Building dashboard components', true);
 *
 *   // Send a chat message (appears in dashboard chat)
 *   rico.sendMessage('Task complete. Ready for next assignment.');
 *
 *   // Create/update a task
 *   rico.createTask('Implement login page', 'high');
 *   rico.completeTask('task-123456');
 *
 *   // Push notification
 *   rico.notify('Build Complete', 'Dashboard v1.0 deployed successfully', 'success');
 */

const http = require('http');

const DASHBOARD_HOST = process.env.DASHBOARD_HOST || 'localhost';
const DASHBOARD_PORT = process.env.DASHBOARD_PORT || 3000;

function post(path, data) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify(data);
    const req = http.request({
      hostname: DASHBOARD_HOST,
      port: DASHBOARD_PORT,
      path,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(body)
      }
    }, (res) => {
      let chunks = '';
      res.on('data', d => chunks += d);
      res.on('end', () => {
        try { resolve(JSON.parse(chunks)); }
        catch { resolve(chunks); }
      });
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

module.exports = {

  /** Post a morning briefing */
  postBriefing(content, title = 'Morning Briefing', sections = []) {
    return post('/api/briefing', { title, content, sections });
  },

  /** Update or create a project */
  updateProject(id, name, progress, status = 'active', description = '') {
    return post('/api/projects', { id, name, progress, status, description });
  },

  /** Log an activity entry */
  log(type, message, meta = {}) {
    return post('/api/activity', { type, message, meta });
  },

  /** Update Rico's status */
  setStatus(currentTask, online = true, custom = {}) {
    return post('/api/status', { currentTask, online, custom });
  },

  /** Send a message to the dashboard chat */
  sendMessage(content) {
    return post('/api/messages', { from: 'rico', content, source: 'rico-api' });
  },

  /** Create or update a task */
  createTask(title, priority = 'medium', status = 'pending') {
    return post('/api/tasks', { title, priority, status });
  },

  /** Complete a task by ID */
  completeTask(taskId) {
    return post('/api/tasks', { id: taskId, status: 'completed' });
  },

  /** Push a notification toast */
  notify(title, message, type = 'info') {
    return post('/api/notifications', { title, message, type });
  },

  /** Mark Rico as going offline */
  goOffline(reason = 'Shutting down') {
    return post('/api/status', { online: false, currentTask: reason });
  },

  /** Mark Rico as coming online */
  goOnline(task = 'Awaiting orders') {
    return post('/api/status', { online: true, currentTask: task });
  }
};
