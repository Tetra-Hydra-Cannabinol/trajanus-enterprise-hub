#!/bin/bash
# TRAJANUS COMMAND CENTER - Deployment Script
# Run this on the VPS to set up the dashboard

echo "╔══════════════════════════════════════════════╗"
echo "║   TRAJANUS COMMAND CENTER - Setup            ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

# Install dependencies
echo "[1/4] Installing dependencies..."
npm install

# Create .env if it doesn't exist
if [ ! -f .env ]; then
  echo "[2/4] Creating .env from template..."
  cp .env.example .env
  echo "  → Edit .env with your Telegram bot token and chat ID"
else
  echo "[2/4] .env already exists, skipping..."
fi

# Create data directory
echo "[3/4] Creating data directory..."
mkdir -p data

# Test start
echo "[4/4] Starting dashboard..."
echo ""
echo "Dashboard will be available at:"
echo "  http://$(curl -s ifconfig.me 2>/dev/null || echo 'YOUR_IP'):3000"
echo ""
echo "To run in background:"
echo "  nohup node server.js > dashboard.log 2>&1 &"
echo ""
echo "To run with auto-restart:"
echo "  npm install -g pm2"
echo "  pm2 start server.js --name rico-dashboard"
echo ""

node server.js
