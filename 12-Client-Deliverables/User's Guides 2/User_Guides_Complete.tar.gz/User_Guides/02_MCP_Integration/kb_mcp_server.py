#!/usr/bin/env python3
"""
Trajanus Knowledge Base MCP Server
Exposes semantic search capabilities to Claude Code via MCP protocol
"""

import sys
import json
import os
from typing import List, Dict
from openai import OpenAI
from supabase import create_client
from dotenv import load_dotenv

load_dotenv()

# Initialize clients
openai_client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))
supabase = create_client(
    os.getenv('SUPABASE_URL'),
    os.getenv('SUPABASE_SERVICE_KEY')
)

EMBEDDING_MODEL = "text-embedding-3-small"
SIMILARITY_THRESHOLD = 0.3


def generate_embedding(text: str) -> List[float]:
    """Generate OpenAI embedding for query"""
    response = openai_client.embeddings.create(
        model=EMBEDDING_MODEL,
        input=text
    )
    return response.data[0].embedding


def search_knowledge_base(query: str, max_results: int = 5) -> Dict:
    """Search knowledge base using vector similarity"""
    try:
        # Generate embedding
        query_embedding = generate_embedding(query)
        
        # Call Supabase function
        result = supabase.rpc(
            'match_knowledge_base',
            {
                'query_embedding': query_embedding,
                'match_threshold': SIMILARITY_THRESHOLD,
                'match_count': max_results
            }
        ).execute()
        
        # Format results
        formatted_results = []
        for doc in result.data:
            formatted_results.append({
                'title': doc['title'],
                'similarity': f"{doc['similarity'] * 100:.1f}%",
                'content': doc['content'],
                'source': doc.get('metadata', {}).get('source', 'Unknown'),
                'url': doc.get('url', '')
            })
        
        return {
            'success': True,
            'query': query,
            'found': len(formatted_results),
            'results': formatted_results
        }
        
    except Exception as e:
        return {
            'success': False,
            'error': str(e),
            'query': query,
            'found': 0,
            'results': []
        }


def handle_mcp_request(request: Dict) -> Dict:
    """Handle MCP protocol requests"""
    method = request.get('method')
    params = request.get('params', {})
    
    if method == 'tools/list':
        return {
            'tools': [
                {
                    'name': 'search_knowledge_base',
                    'description': 'Search Trajanus knowledge base using semantic similarity. Returns relevant documentation, session history, protocols, and code examples based on natural language queries.',
                    'inputSchema': {
                        'type': 'object',
                        'properties': {
                            'query': {
                                'type': 'string',
                                'description': 'Natural language search query (e.g., "December 9 accomplishments", "RAG system setup", "QCM workflow")'
                            },
                            'max_results': {
                                'type': 'integer',
                                'description': 'Maximum number of results to return (1-20)',
                                'default': 5
                            }
                        },
                        'required': ['query']
                    }
                }
            ]
        }
    
    elif method == 'tools/call':
        tool_name = params.get('name')
        args = params.get('arguments', {})
        
        if tool_name == 'search_knowledge_base':
            query = args.get('query')
            max_results = args.get('max_results', 5)
            
            result = search_knowledge_base(query, max_results)
            
            # Format for MCP response
            if result['success']:
                content = f"Found {result['found']} relevant documents:\n\n"
                for idx, doc in enumerate(result['results'], 1):
                    content += f"{idx}. {doc['title']} (Similarity: {doc['similarity']})\n"
                    content += f"   Source: {doc['source']}\n"
                    content += f"   Content: {doc['content'][:200]}...\n\n"
            else:
                content = f"Search failed: {result.get('error', 'Unknown error')}"
            
            return {
                'content': [
                    {
                        'type': 'text',
                        'text': content
                    }
                ]
            }
    
    return {'error': 'Unknown method or tool'}


def main():
    """Main MCP server loop"""
    # Send initialization response
    print(json.dumps({
        'jsonrpc': '2.0',
        'id': 0,
        'result': {
            'protocolVersion': '2024-11-05',
            'capabilities': {
                'tools': {}
            },
            'serverInfo': {
                'name': 'trajanus-kb',
                'version': '1.0.0'
            }
        }
    }))
    sys.stdout.flush()
    
    # Handle incoming requests
    for line in sys.stdin:
        try:
            request = json.loads(line)
            response = handle_mcp_request(request)
            
            print(json.dumps({
                'jsonrpc': '2.0',
                'id': request.get('id'),
                'result': response
            }))
            sys.stdout.flush()
            
        except Exception as e:
            print(json.dumps({
                'jsonrpc': '2.0',
                'id': request.get('id') if 'request' in locals() else None,
                'error': {
                    'code': -32603,
                    'message': str(e)
                }
            }), file=sys.stderr)
            sys.stderr.flush()


if __name__ == "__main__":
    main()
