# TRAJANUS USER GUIDES - COMPLETE MASTER INDEX
**Version:** 1.0  
**Date:** December 11, 2025  
**Total Files:** 29 documents

---

## QUICK REFERENCE

**START HERE:**
1. [README.md](./README.md) - Overview and getting started
2. [HOW_TO_ACCESS_KB.md](./HOW_TO_ACCESS_KB.md) - Essential for Claude sessions
3. [SYSTEM_ARCHITECTURE.md](./04_System_Architecture/SYSTEM_ARCHITECTURE.md) - Technical specs

**MOST IMPORTANT:**
- Query knowledge base: `python query_kb.py`
- Read protocols before each session
- Follow End of Session procedures

---

## 📁 01_RAG_SYSTEM (3 files)

### RAG_IMPLEMENTATION_PLAN.md
**Purpose:** Complete roadmap for RAG system development  
**Contents:**
- Phase 1 (Complete): Foundation with 1646 documents
- Phase 2 (Planned): Building codes ingestion
- Phase 3 (Planned): USACE standards
- Phase 4-5 (Planned): Multi-tenant commercial product
**Use:** Reference for project planning and milestones

### query_kb.py
**Purpose:** Interactive CLI tool for searching knowledge base  
**Usage:**
```bash
cd "G:\My Drive\00 - Trajanus USA\00-Command-Center\05-Scripts"
python query_kb.py
```
**Commands:**
- `search <query>` - Semantic search
- `recent` - Recent sessions
- `sources` - List all sources
- `exit` - Quit

### query_kb_json.py
**Purpose:** Programmatic access with JSON output  
**Usage:** For automation scripts and integrations  
**Returns:** Structured JSON data

---

## 📁 02_MCP_INTEGRATION (4 files)

### DEPLOYMENT_GUIDE.md
**Purpose:** Complete setup instructions for MCP servers  
**Contents:**
- Local testing procedures
- Cloud deployment options
- Security configuration
- Troubleshooting guide

### kb_mcp_server.py
**Purpose:** stdio MCP server for Claude Code CLI  
**Status:** ✅ Working  
**Usage:** Configured in ~/.config/claude/mcp.json

### kb_mcp_server_http.py
**Purpose:** HTTP MCP server for web chat access  
**Status:** ⏳ Ready to deploy  
**Endpoints:**
- GET /health - Health check
- GET /sse - SSE connection
- POST /message - Tool calls

### requirements_http_mcp.txt
**Purpose:** Python dependencies for HTTP server  
**Contents:**
- flask>=3.0.0
- flask-cors>=4.0.0
- openai>=1.6.1
- supabase>=2.3.0
- python-dotenv>=1.0.0

---

## 📁 03_CORE_PROTOCOLS (11 files)

### Morning_Session_Startup.docx
**Purpose:** Protocol #1 - Start every session  
**Contents:**
1. Verify project location
2. Load Bills_Profile
3. Assess context needs
4. Greet + status report
5. Begin work
**Critical:** Never skip this

### End_Of_Session_Closeout.docx
**Purpose:** Session completion checklist  
**Contents:**
- Work completion verification
- File inventory
- **MANDATORY download reminder**
- Session summary creation
- Token monitoring
- Emergency closeout procedures

### The_Commandments_of_AI.docx
**Purpose:** 12 inviolable rules for AI collaboration  
**Key Rules:**
- Commandment I: Download all files
- Token monitoring required
- File persistence warnings
- Documentation standards
**Status:** Living document - add as needed

### OPERATIONAL_PROTOCOL.md
**Purpose:** Complete operational standard  
**Scope:**
- Communication protocol
- File organization standards
- Memory management
- Session handling
**Critical:** This is THE standard, not a suggestion

### Bills_Profile.docx
**Purpose:** Complete context about Bill King  
**Contents:**
- Professional background
- Current projects (SOUTHCOM)
- Communication preferences
- Business context
**Use:** Load at session start for context

### 6_Category_System_Guide.docx
**Purpose:** Framework architecture explanation  
**Six Categories:**
1. Core Protocols
2. Memory System
3. Dialogue Patterns
4. Technical Specs
5. Decision Logs
6. Project State
**Value:** Marketable IP ($3M-15M TAM)

### File_Systems_User_Guide.docx
**Purpose:** CRITICAL - Explains two file systems  
**Key Insight:** Claude temporary vs. Bill permanent  
**Construction Trailer Analogy:** Bill's best explanation  
**Must Read:** Foundation for understanding system

### Operational_Protocols.docx
**Purpose:** Operational procedures and standards  
**Contents:** Standard operating procedures

### Claude_Protocol_Violation_Log.md
**Purpose:** Track recurring errors  
**Use:** Anthropic support escalation  
**Examples:**
- Formatting violations
- Failed documentation updates
- Poor screenshot analysis

### Protocol_Violations_Log.md
**Purpose:** Alternative format for error tracking  
**Use:** Pattern analysis

### TRAJANUS_FILE_STRUCTURE_MAP.md
**Purpose:** Complete folder structure reference  
**Contents:**
- 12 numbered folders (00-12)
- Naming conventions
- Organization standards
**Updated:** October 30, 2025

---

## 📁 04_SYSTEM_ARCHITECTURE (4 files)

### SYSTEM_ARCHITECTURE.md
**Purpose:** Complete technical documentation  
**Contents:**
- Data storage layer (Supabase)
- Embedding generation (OpenAI)
- Query interface (Python)
- MCP servers (stdio/HTTP)
- Client interfaces
- Performance metrics
**Size:** Comprehensive (~5000 words)

### AI_Integration_Plan.md
**Purpose:** 16-week implementation roadmap  
**Phases:**
- Week 1-2: Development environment setup
- Week 3-6: QCM submittal automation
- Week 7-10: P6 schedule intelligence
- Week 11-14: Earned value analytics
- Week 15-16: Production launch
**Originally:** October 24, 2025

### START_HERE_Implementation_Guide.md
**Purpose:** Week-by-week startup guide  
**Timeline:** First 4 weeks of system setup  
**Contents:**
- Week 1 tasks
- Backup procedures
- Emergency contacts
- Operations manual
**Practical:** Actionable daily tasks

### Trajanus_USA_Backup_Business_Continuity_Plan.md
**Purpose:** Complete backup and disaster recovery  
**Scope:**
- Multi-layer backup strategy
- Critical systems inventory
- Daily/weekly/monthly routines
- Disaster recovery procedures
- AI independence strategy
**Status:** Version 1.0

---

## 📁 05_CODE_REPOSITORY (7 files)

### google_drive_manager.py
**Purpose:** Google Drive API wrapper  
**Features:**
- Authentication handling
- File upload/download
- Folder creation
- File management
**Date:** October 27, 2025 (corrected version)

### query_kb.py
**Purpose:** Interactive knowledge base search  
**Also listed in:** 01_RAG_System/  
**Note:** Master copy for daily use

### batch_ingest.py
**Purpose:** Bulk document ingestion to knowledge base  
**Usage:** Process multiple files at once  
**Input:** Folder path with documents  
**Output:** Embedded chunks in Supabase

### crawl_building_codes.py
**Purpose:** Web scraper for building codes  
**Target:** NFPA 70, IBC, UFC standards  
**Status:** Ready for Phase 2

### file_ingestion.py
**Purpose:** Single file ingestion to knowledge base  
**Usage:** Add individual documents  
**Process:** Read → Chunk → Embed → Store

### live_crawler.py
**Purpose:** Real-time website crawling  
**Use:** Continuous documentation updates  
**Status:** Operational

### qcm_agent.py
**Purpose:** QCM submittal review automation  
**Features:**
- PDF parsing
- Checklist completion
- Deficiency detection
**Status:** Development stage

### test_crawler.py
**Purpose:** Testing framework for crawlers  
**Use:** Validate before production runs

---

## USAGE SCENARIOS

### **Scenario 1: Starting New Claude Session**

1. Open new chat
2. Claude searches: "HOW_TO_ACCESS_KB"
3. Claude reads access instructions
4. Claude confirms: "Ready to search knowledge base"
5. Begin work with full context

### **Scenario 2: Querying Knowledge Base**

```bash
# Interactive mode
cd "G:\My Drive\00 - Trajanus USA\00-Command-Center\05-Scripts"
python query_kb.py

# One-off query
python -c "from query_kb import search_knowledge; search_knowledge('December 9')"
```

### **Scenario 3: Adding New Documents**

```bash
# Single file
python file_ingestion.py --file path/to/document.md

# Bulk folder
python batch_ingest.py --folder path/to/sessions/
```

### **Scenario 4: Deploying HTTP MCP Server**

```bash
# Local test
python kb_mcp_server_http.py

# Public via ngrok
ngrok http 5000

# Cloud deployment
# See DEPLOYMENT_GUIDE.md
```

### **Scenario 5: Following Protocols**

**Morning:**
1. Read Morning_Session_Startup.docx
2. Execute Protocol #1
3. Load Bills_Profile
4. Begin session

**Evening:**
1. Read End_Of_Session_Closeout.docx
2. Complete checklist
3. Download all files
4. Create session summary

---

## FILE CATEGORIES

### 📘 **Essential Reading (Start Here)**
- README.md
- HOW_TO_ACCESS_KB.md
- Morning_Session_Startup.docx
- End_Of_Session_Closeout.docx

### 📗 **Daily Operations**
- query_kb.py
- OPERATIONAL_PROTOCOL.md
- File_Systems_User_Guide.docx

### 📙 **Technical Reference**
- SYSTEM_ARCHITECTURE.md
- DEPLOYMENT_GUIDE.md
- AI_Integration_Plan.md

### 📕 **Protocols & Standards**
- The_Commandments_of_AI.docx
- 6_Category_System_Guide.docx
- Bills_Profile.docx
- Protocol_Violations_Log.md

### 📓 **Code & Scripts**
- All files in 05_Code_Repository/
- MCP servers in 02_MCP_Integration/

### 📔 **Planning & Strategy**
- RAG_IMPLEMENTATION_PLAN.md
- START_HERE_Implementation_Guide.md
- Trajanus_USA_Backup_Business_Continuity_Plan.md

---

## DOCUMENT VERSIONS

**Latest Versions:**
- System Architecture: v1.0 (Dec 11, 2025)
- RAG Implementation: v1.0 (Dec 11, 2025)
- HOW_TO_ACCESS_KB: v1.0 (Dec 11, 2025)
- Backup Plan: v1.0 (Oct 29, 2025)
- AI Integration Plan: v1.0 (Oct 24, 2025)

**Historical:**
- Google Drive Manager: Oct 27, 2025 (corrected)
- Protocol Violations: Oct 30, 2025
- File Structure Map: Oct 30, 2025

---

## MAINTENANCE

**Weekly:**
- Ingest new session documents
- Update FILE_MANIFEST.txt
- Check for protocol updates

**Monthly:**
- Review and refine documentation
- Archive superseded versions
- Update version numbers

**Quarterly:**
- Complete documentation audit
- User guide improvements
- Add new learnings

---

## GETTING HELP

**Documentation Issues:**
- Check README.md first
- Review relevant protocol
- Search knowledge base

**Technical Issues:**
- Check DEPLOYMENT_GUIDE.md
- Review SYSTEM_ARCHITECTURE.md
- Test with query_kb.py

**Process Questions:**
- Read OPERATIONAL_PROTOCOL.md
- Check Morning/End protocols
- Review The_Commandments_of_AI

---

## STATISTICS

**Total Files:** 29  
**Total Categories:** 5  
**Documentation Pages:** ~150+  
**Code Files:** 7  
**Protocol Documents:** 11  
**Last Updated:** December 11, 2025

---

## WHAT'S NEXT

**Immediate (This Week):**
- Deploy HTTP MCP server
- Test all access methods
- Train Tom on system

**Short-term (This Month):**
- Begin Phase 2 (building codes)
- Add USACE standards
- Create training materials

**Long-term (Q1-Q2 2026):**
- Multi-project architecture
- Commercial product launch
- Scale to 100+ clients

---

**REMEMBER:** This folder contains everything you need to operate the Trajanus Knowledge Base system. Start with README.md, understand HOW_TO_ACCESS_KB.md, and always follow the protocols.

**For Claude:** This is your complete reference library. Every session should begin with accessing these resources.

**For Bill:** This is your permanent documentation set. Keep it updated, backed up, and accessible.

**For Tom:** This is your onboarding package. Start here, work through systematically, and you'll understand the entire system.

---

**Last Updated:** December 11, 2025  
**Maintained By:** Bill King & Claude  
**Status:** Complete and Production Ready
