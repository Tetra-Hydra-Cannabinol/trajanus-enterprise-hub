# TRAJANUS USA - USER GUIDES
## Complete Documentation Package
**Version:** 1.0  
**Date:** December 11, 2025  
**Purpose:** Comprehensive documentation for RAG system, MCP integration, and operational protocols

---

## QUICK START

**New to the system?** Start here:
1. Read [HOW_TO_ACCESS_KB.md](./HOW_TO_ACCESS_KB.md)
2. Review [SYSTEM_ARCHITECTURE.md](./04_System_Architecture/SYSTEM_ARCHITECTURE.md)
3. Check [DEPLOYMENT_GUIDE.md](./02_MCP_Integration/DEPLOYMENT_GUIDE.md)

**Need to search knowledge base?**
```bash
cd "G:\My Drive\00 - Trajanus USA\00-Command-Center\05-Scripts"
python query_kb.py
```

**Setting up MCP integration?**
See [02_MCP_Integration/](./02_MCP_Integration/)

---

## FOLDER STRUCTURE

```
User_Guides/
├── README.md (this file)
├── HOW_TO_ACCESS_KB.md ⭐ START HERE
│
├── 01_RAG_System/
│   ├── query_kb.py - Interactive search tool
│   └── query_kb_json.py - JSON output version
│
├── 02_MCP_Integration/
│   ├── kb_mcp_server.py - stdio MCP server (CLI)
│   ├── kb_mcp_server_http.py - HTTP MCP server (Web)
│   ├── requirements_http_mcp.txt - Python dependencies
│   └── DEPLOYMENT_GUIDE.md - Setup instructions
│
├── 03_Core_Protocols/
│   └── (To be populated from project knowledge)
│
├── 04_System_Architecture/
│   └── SYSTEM_ARCHITECTURE.md - Complete technical specs
│
└── 05_Code_Repository/
    └── (Python scripts, utilities, examples)
```

---

## DOCUMENT INDEX

### GETTING STARTED

**[HOW_TO_ACCESS_KB.md](./HOW_TO_ACCESS_KB.md)**  
→ Essential guide for future Claude sessions  
→ How to query the knowledge base  
→ Credentials location and access methods  
→ Troubleshooting common issues

**[SYSTEM_ARCHITECTURE.md](./04_System_Architecture/SYSTEM_ARCHITECTURE.md)**  
→ Complete system design and data flow  
→ Component descriptions and diagrams  
→ Performance metrics and scalability  
→ Future enhancements roadmap

**[DEPLOYMENT_GUIDE.md](./02_MCP_Integration/DEPLOYMENT_GUIDE.md)**  
→ Step-by-step deployment instructions  
→ Local testing procedures  
→ Cloud deployment options  
→ Security configuration

### RAG SYSTEM

**Purpose:** Persistent AI memory through vector database

**Components:**
- **Supabase PostgreSQL:** Cloud database with pgvector
- **OpenAI Embeddings:** text-embedding-3-small model
- **Python Scripts:** Query tools and ingestion pipelines

**Current Status:**
- ✅ 1646 documents indexed
- ✅ Semantic search operational
- ✅ CLI access working
- ⏳ Web access pending deployment

**Key Files:**
- `query_kb.py` - Main interactive tool
- `query_kb_json.py` - Programmatic access
- `file_ingestion.py` - Add new documents

### MCP INTEGRATION

**Purpose:** Enable Claude instances to search knowledge base

**Two Transports:**

1. **stdio** (Local CLI) - ✅ Working
   - File: `kb_mcp_server.py`
   - Use: Claude Code terminal access
   - Config: ~/.config/claude/mcp.json

2. **HTTP/SSE** (Web Chat) - ⏳ Ready to deploy
   - File: `kb_mcp_server_http.py`
   - Use: Web chat at claude.ai
   - Deploy: Local/ngrok/cloud

**Testing:**
```bash
# Test stdio version
python kb_mcp_server.py

# Test HTTP version
python kb_mcp_server_http.py
curl http://localhost:5000/health
```

### CORE PROTOCOLS

**To be added from project knowledge:**
- Morning_Session_Startup.docx
- End_Of_Session_Closeout.docx
- OPERATIONAL_PROTOCOL.md
- The_Commandments_of_AI.docx
- File_Systems_User_Guide.docx
- 6_Category_System_Guide.docx

**Purpose:** Operational procedures and standards

### SYSTEM ARCHITECTURE

**Complete technical documentation:**
- Data storage layer (Supabase)
- Embedding generation (OpenAI)
- Query interface (Python)
- MCP servers (stdio/HTTP)
- Client interfaces (Web/CLI/Hub)

**See:** [SYSTEM_ARCHITECTURE.md](./04_System_Architecture/SYSTEM_ARCHITECTURE.md)

### CODE REPOSITORY

**Python Scripts:**
- query_kb.py - Main search tool
- kb_mcp_server.py - stdio MCP
- kb_mcp_server_http.py - HTTP MCP
- file_ingestion.py - Document ingestion
- batch_ingest.py - Bulk processing

**Future Additions:**
- Enterprise Hub integration code
- Automation scripts
- Utility functions
- Test suites

---

## ACCESS METHODS

### For Bill (Developer/Admin)

**Option 1: Python Script** ⭐ Recommended
```bash
cd "G:\My Drive\00 - Trajanus USA\00-Command-Center\05-Scripts"
python query_kb.py
```

**Option 2: Claude Code CLI**
```bash
claude
> Search knowledge base for December 9
```

**Option 3: Direct Python**
```python
from query_kb import search_knowledge
results = search_knowledge("December 9", limit=5)
```

### For Tom (End User)

**Trajanus Enterprise Hub** (Future)
- Opens application
- Uses chat interface
- Knowledge base accessed automatically
- No technical knowledge required

### For Future Claude Instances

**Web Chat:**
1. Search project knowledge for "HOW_TO_ACCESS_KB"
2. Read access instructions
3. Use MCP server (when deployed)
4. OR ask Bill to run query_kb.py

**Claude Code:**
1. Check MCP configuration
2. Use search_knowledge_base tool directly
3. Results appear in terminal

---

## TYPICAL WORKFLOWS

### Searching Recent Work

```bash
# Interactive
python query_kb.py
Query> search December 9 accomplishments
Query> recent

# Programmatic
python -c "from query_kb import search_knowledge; search_knowledge('December 9')"
```

### Adding New Documents

```bash
# Single file
python file_ingestion.py --file path/to/document.md

# Bulk folder
python batch_ingest.py --folder path/to/sessions/
```

### Deploying HTTP Server

```bash
# Local test
python kb_mcp_server_http.py

# Public access via ngrok
ngrok http 5000

# Cloud deployment
# See DEPLOYMENT_GUIDE.md
```

---

## SYSTEM REQUIREMENTS

**Python:**
- Version: 3.8+
- Packages: See requirements_http_mcp.txt

**Dependencies:**
- openai>=1.6.1
- supabase>=2.3.0
- python-dotenv>=1.0.0
- flask>=3.0.0 (for HTTP server)
- flask-cors>=4.0.0 (for HTTP server)

**Credentials:**
- OPENAI_API_KEY
- SUPABASE_URL
- SUPABASE_SERVICE_KEY

**Storage:**
- Location: `.env` file in 05-Scripts folder
- Format: KEY=value pairs
- Security: Never commit to Git

---

## PERFORMANCE

**Search Speed:** <5s end-to-end  
**Accuracy:** 60-90% similarity typical  
**Capacity:** 1646 docs (scalable to 10K+)  
**Cost:** <$5/month for typical usage

**Benchmarks:**
- Embedding generation: ~3s
- Vector search: <2s
- Result formatting: <1s

---

## TROUBLESHOOTING

### Connection Issues

**Problem:** 403 Forbidden  
**Solution:** Check SUPABASE_SERVICE_KEY format (must be full JWT)

**Problem:** Network error  
**Solution:** Verify internet connection, check API endpoints

### Search Issues

**Problem:** No results  
**Solution:** Lower similarity threshold, check `sources` command

**Problem:** Slow queries  
**Solution:** Check OpenAI API status, test network latency

### MCP Issues

**Problem:** Tool not available  
**Solution:** Verify MCP config, check server is running

**Problem:** HTTP server won't start  
**Solution:** Check port 5000 availability, verify dependencies

---

## SUPPORT

**Primary Contact:** Bill King, Principal/CEO, Trajanus USA

**Documentation:**
- This README
- HOW_TO_ACCESS_KB.md
- SYSTEM_ARCHITECTURE.md
- DEPLOYMENT_GUIDE.md

**Code Location:**
- Main: `G:\My Drive\00 - Trajanus USA\00-Command-Center\05-Scripts\`
- Backup: Project knowledge in Claude

**Resources:**
- Supabase Dashboard: https://supabase.com/dashboard
- OpenAI Platform: https://platform.openai.com
- Anthropic Console: https://console.anthropic.com

---

## VERSION HISTORY

**v1.0 (2025-12-11)**
- Initial documentation package
- RAG system complete
- MCP integration ready
- Architecture documented
- Access methods defined

**Planned:**
- v1.1: Add building codes integration
- v1.2: Add USACE standards
- v1.3: Multi-tenant support
- v2.0: Enterprise Hub integration

---

## NEXT STEPS

**Immediate:**
1. ✅ Documentation complete
2. ⏳ Test HTTP MCP server locally
3. ⏳ Deploy to ngrok/cloud
4. ⏳ Configure web chat access

**This Week:**
1. Add core protocols to folder 03
2. Create code examples in folder 05
3. Test end-to-end workflows
4. Document lessons learned

**This Month:**
1. Begin building codes ingestion
2. Plan USACE standards integration
3. Design Enterprise Hub integration
4. Prepare Tom onboarding materials

---

## LICENSE & COPYRIGHT

**Copyright © 2025 Trajanus USA**  
**Proprietary and Confidential**

This documentation is the intellectual property of Trajanus USA. Unauthorized distribution, reproduction, or use is prohibited.

**For commercial licensing inquiries, contact Bill King.**

---

**Last Updated:** December 11, 2025  
**Maintained By:** Bill King & Claude (AI Collaboration)  
**Status:** Production Ready - Phase 1 Complete
