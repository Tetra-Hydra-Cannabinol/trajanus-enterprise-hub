"""
Trajanus RAG System - Building Code Crawler
Scrapes building codes and stores in Supabase for agentic RAG

Based on training from:
- Crawl4AI best practices (parallel processing, memory efficiency)
- Agentic RAG architecture (chunking, metadata, embeddings)
- Claude Code workflows (modular, reusable, documented)
"""

import asyncio
import os
from datetime import datetime
from typing import List, Dict, Optional
import xml.etree.ElementTree as ET
from dataclasses import dataclass
import json

# External dependencies
from crawl4ai import AsyncWebCrawler
from openai import OpenAI
from supabase import create_client, Client
from dotenv import load_dotenv

# Load environment
load_dotenv()

# Initialize clients
openai_client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))
supabase: Client = create_client(
    os.getenv('SUPABASE_URL'),
    os.getenv('SUPABASE_SERVICE_KEY')
)

# Configuration
EMBEDDING_MODEL = "text-embedding-3-small"
LLM_MODEL = "gpt-4o-mini"
CHUNK_SIZE = 2000  # Characters per chunk
CHUNK_OVERLAP = 200  # Character overlap between chunks
BATCH_SIZE = 10  # Parallel processing batch size


@dataclass
class ProcessedChunk:
    """Data structure for processed knowledge chunk"""
    url: str
    chunk_number: int
    title: str
    summary: str
    content: str
    metadata: Dict
    embedding: List[float]


class BuildingCodeCrawler:
    """
    Crawls building code websites and prepares for agentic RAG
    
    Features:
    - Parallel URL processing
    - Intelligent chunking (respects code blocks, paragraphs)
    - AI-generated titles and summaries
    - Vector embeddings for semantic search
    - Metadata for filtering and routing
    """
    
    def __init__(self, source_name: str, base_url: str):
        self.source_name = source_name
        self.base_url = base_url
        self.crawled_pages = []
        
    async def get_sitemap_urls(self, sitemap_url: str) -> List[str]:
        """
        Extract all URLs from sitemap.xml
        
        Args:
            sitemap_url: Full URL to sitemap.xml
            
        Returns:
            List of URLs found in sitemap
        """
        async with AsyncWebCrawler() as crawler:
            result = await crawler.arun(sitemap_url)
            
        # Parse XML
        root = ET.fromstring(result.markdown)
        namespace = {'ns': 'http://www.sitemaps.org/schemas/sitemap/0.9'}
        
        urls = []
        for url in root.findall('.//ns:loc', namespace):
            urls.append(url.text)
            
        print(f"Found {len(urls)} URLs in sitemap")
        return urls
    
    async def crawl_urls_parallel(self, urls: List[str]) -> List[Dict]:
        """
        Crawl multiple URLs in parallel batches
        
        Args:
            urls: List of URLs to crawl
            
        Returns:
            List of crawl results with markdown content
        """
        results = []
        
        async with AsyncWebCrawler() as crawler:
            for i in range(0, len(urls), BATCH_SIZE):
                batch = urls[i:i + BATCH_SIZE]
                print(f"Processing batch {i//BATCH_SIZE + 1} ({len(batch)} URLs)...")
                
                batch_results = await crawler.arun_many(
                    batch,
                    word_count_threshold=50
                )
                
                for result in batch_results:
                    if result.success:
                        results.append({
                            'url': result.url,
                            'content': result.markdown,
                            'crawled_at': datetime.now().isoformat()
                        })
                        print(f"✓ Crawled: {result.url} ({len(result.markdown)} chars)")
                    else:
                        print(f"✗ Failed: {result.url}")
                        
        return results
    
    def chunk_text(self, text: str) -> List[str]:
        """
        Split text into chunks respecting code blocks and paragraphs
        
        Strategy:
        1. Try to end chunks at paragraph boundaries
        2. Never split code blocks (```)
        3. Maintain overlap for context continuity
        
        Args:
            text: Full document text
            
        Returns:
            List of text chunks
        """
        chunks = []
        current_pos = 0
        
        while current_pos < len(text):
            # Calculate chunk boundaries
            end_pos = min(current_pos + CHUNK_SIZE, len(text))
            
            if end_pos == len(text):
                # Last chunk - take everything remaining
                chunks.append(text[current_pos:].strip())
                break
            
            # Try to find code block boundary
            chunk_text = text[current_pos:end_pos + 100]  # Look ahead
            code_block_end = chunk_text.rfind('```\n')
            
            if code_block_end != -1 and code_block_end < CHUNK_SIZE:
                # End after code block
                end_pos = current_pos + code_block_end + 4
            else:
                # Try to find paragraph boundary
                paragraph_end = chunk_text.rfind('\n\n')
                if paragraph_end != -1 and paragraph_end > CHUNK_SIZE // 2:
                    end_pos = current_pos + paragraph_end
                else:
                    # Try sentence boundary
                    sentence_end = chunk_text.rfind('. ')
                    if sentence_end != -1 and sentence_end > CHUNK_SIZE // 2:
                        end_pos = current_pos + sentence_end + 1
            
            # Extract chunk
            chunk = text[current_pos:end_pos].strip()
            if chunk:
                chunks.append(chunk)
            
            # Move forward with overlap
            current_pos = end_pos - CHUNK_OVERLAP
        
        return chunks
    
    def get_chunk_title_and_summary(self, chunk: str) -> Dict[str, str]:
        """
        Use LLM to generate title and summary for chunk
        
        Args:
            chunk: Text content of chunk
            
        Returns:
            Dict with 'title' and 'summary' keys
        """
        system_prompt = """Extract a concise title and summary from this text chunk.
Return JSON format: {"title": "...", "summary": "..."}
Title: 5-10 words describing main topic
Summary: 1-2 sentences explaining content"""
        
        try:
            response = openai_client.chat.completions.create(
                model=LLM_MODEL,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": chunk[:1000]}  # First 1000 chars
                ],
                response_format={"type": "json_object"}
            )
            
            return json.loads(response.choices[0].message.content)
            
        except Exception as e:
            print(f"Error generating title/summary: {e}")
            return {
                "title": "Unknown Section",
                "summary": "Content chunk from documentation"
            }
    
    def get_embedding(self, text: str) -> List[float]:
        """
        Generate vector embedding for text
        
        Args:
            text: Text to embed
            
        Returns:
            Embedding vector (1536 dimensions for text-embedding-3-small)
        """
        try:
            response = openai_client.embeddings.create(
                model=EMBEDDING_MODEL,
                input=text
            )
            return response.data[0].embedding
            
        except Exception as e:
            print(f"Error generating embedding: {e}")
            return [0.0] * 1536  # Zero vector as fallback
    
    async def process_chunk(
        self,
        chunk: str,
        chunk_number: int,
        url: str,
        total_chunks: int
    ) -> ProcessedChunk:
        """
        Process single chunk: title, summary, embedding
        
        Args:
            chunk: Raw text chunk
            chunk_number: Position in document (1-indexed)
            url: Source URL
            total_chunks: Total chunks for this document
            
        Returns:
            ProcessedChunk with all fields populated
        """
        print(f"  Processing chunk {chunk_number}/{total_chunks}...")
        
        # Generate title and summary
        title_summary = self.get_chunk_title_and_summary(chunk)
        
        # Generate embedding
        embedding = self.get_embedding(chunk)
        
        # Create metadata
        metadata = {
            'source': self.source_name,
            'crawl_date': datetime.now().isoformat(),
            'chunk_total': total_chunks,
            'chunk_size': len(chunk)
        }
        
        return ProcessedChunk(
            url=url,
            chunk_number=chunk_number,
            title=title_summary['title'],
            summary=title_summary['summary'],
            content=chunk,
            metadata=metadata,
            embedding=embedding
        )
    
    async def store_chunk(self, chunk: ProcessedChunk) -> bool:
        """
        Store processed chunk in Supabase
        
        Args:
            chunk: Processed chunk to store
            
        Returns:
            True if successful, False otherwise
        """
        try:
            data = {
                'url': chunk.url,
                'chunk_number': chunk.chunk_number,
                'title': chunk.title,
                'summary': chunk.summary,
                'content': chunk.content,
                'metadata': chunk.metadata,
                'embedding': chunk.embedding
            }
            
            result = supabase.table('knowledge_base').insert(data).execute()
            return True
            
        except Exception as e:
            print(f"Error storing chunk: {e}")
            return False
    
    async def process_and_store_document(self, doc: Dict):
        """
        Complete pipeline: chunk → process → store
        
        Args:
            doc: Document dict with 'url', 'content', 'crawled_at'
        """
        print(f"\n{'='*60}")
        print(f"Processing: {doc['url']}")
        print(f"{'='*60}")
        
        # Step 1: Chunk the text
        chunks = self.chunk_text(doc['content'])
        print(f"Created {len(chunks)} chunks")
        
        # Step 2: Process all chunks in parallel
        tasks = [
            self.process_chunk(chunk, i+1, doc['url'], len(chunks))
            for i, chunk in enumerate(chunks)
        ]
        processed_chunks = await asyncio.gather(*tasks)
        
        # Step 3: Store all chunks
        print(f"Storing {len(processed_chunks)} chunks...")
        for chunk in processed_chunks:
            await self.store_chunk(chunk)
        
        print(f"✓ Complete: {doc['url']}\n")
    
    async def crawl_and_store(self, sitemap_url: Optional[str] = None, urls: Optional[List[str]] = None):
        """
        Main entry point: crawl sources and store in knowledge base
        
        Args:
            sitemap_url: URL to sitemap.xml (if available)
            urls: Manual list of URLs (if no sitemap)
        """
        print(f"\n{'#'*60}")
        print(f"# Trajanus RAG System - {self.source_name}")
        print(f"{'#'*60}\n")
        
        # Get URLs
        if sitemap_url:
            urls = await self.get_sitemap_urls(sitemap_url)
        elif not urls:
            raise ValueError("Must provide either sitemap_url or urls list")
        
        # Crawl all URLs
        print(f"\nCrawling {len(urls)} pages...")
        documents = await self.crawl_urls_parallel(urls)
        
        # Process and store each document
        print(f"\nProcessing {len(documents)} documents...")
        for doc in documents:
            await self.process_and_store_document(doc)
        
        print(f"\n{'#'*60}")
        print(f"# COMPLETE: {self.source_name}")
        print(f"# Total pages: {len(documents)}")
        print(f"{'#'*60}\n")


# Example usage functions
async def crawl_nfpa70():
    """Crawl NFPA 70 documentation"""
    crawler = BuildingCodeCrawler(
        source_name="NFPA 70 (NEC)",
        base_url="https://nfpa.org"
    )
    
    # Note: NFPA requires authentication, this is example structure
    # You'll need to provide actual accessible URLs or PDF processing
    urls = [
        "https://nfpa.org/codes-and-standards/nfpa-70/article-90",
        "https://nfpa.org/codes-and-standards/nfpa-70/article-110",
        # ... more URLs
    ]
    
    await crawler.crawl_and_store(urls=urls)


async def crawl_ibc():
    """Crawl IBC documentation"""
    crawler = BuildingCodeCrawler(
        source_name="IBC 2021",
        base_url="https://codes.iccsafe.org"
    )
    
    sitemap_url = "https://codes.iccsafe.org/sitemap.xml"
    await crawler.crawl_and_store(sitemap_url=sitemap_url)


async def crawl_ufc():
    """Crawl UFC standards"""
    crawler = BuildingCodeCrawler(
        source_name="UFC Standards",
        base_url="https://www.wbdg.org"
    )
    
    sitemap_url = "https://www.wbdg.org/ffc/dod/unified-facilities-criteria-ufc/sitemap.xml"
    await crawler.crawl_and_store(sitemap_url=sitemap_url)


# Main execution
if __name__ == "__main__":
    # Run crawlers
    asyncio.run(crawl_nfpa70())
    # asyncio.run(crawl_ibc())
    # asyncio.run(crawl_ufc())
