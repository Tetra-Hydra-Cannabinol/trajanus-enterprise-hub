# HOW TO ACCESS THE KNOWLEDGE BASE
**Created:** December 11, 2025  
**Purpose:** Instructions for future Claude sessions to access the Trajanus Knowledge Base

---

## OVERVIEW

The Trajanus Knowledge Base is a cloud-hosted Supabase PostgreSQL database containing **1646 documents** with vector embeddings for semantic search. It stores session history, living documents, core protocols, and will eventually include building codes and USACE standards.

**Location:** https://iaxtwrswinygwwwdkvok.supabase.co  
**Storage Type:** Cloud (NOT local - accessible from anywhere)  
**Access Method:** Python scripts + MCP servers

---

## FOR CLAUDE INSTANCES (Future Sessions)

### Method 1: Python Query Script (Simplest)

**Location:** `G:\My Drive\00 - Trajanus USA\00-Command-Center\05-Scripts\query_kb.py`

**How to use:**
```bash
cd "G:\My Drive\00 - Trajanus USA\00-Command-Center\05-Scripts"
python query_kb.py
```

**Interactive commands:**
- `search <query>` - Semantic search
- `recent` - Show recent sessions
- `sources` - List all sources
- `source <name>` - Get docs from specific source
- `exit` - Quit

**Example:**
```
Query> search December 9 RAG implementation
Query> recent
Query> sources
```

### Method 2: MCP Server (Claude Code CLI)

**For stdio transport (local CLI):**

Configuration location: `~/.config/claude/mcp.json` (or equivalent)

```json
{
  "trajanus-kb": {
    "command": "python",
    "args": ["G:/My Drive/00 - Trajanus USA/00-Command-Center/05-Scripts/kb_mcp_server.py"],
    "env": {
      "SUPABASE_URL": "https://iaxtwrswinygwwwdkvok.supabase.co",
      "SUPABASE_SERVICE_KEY": "[in .env file]",
      "OPENAI_API_KEY": "[in .env file]"
    }
  }
}
```

**Then in Claude Code:**
```
claude
> Search knowledge base for December 9 accomplishments
```

### Method 3: HTTP MCP Server (Future Web Chat)

**When deployed:**

The HTTP MCP server (`kb_mcp_server_http.py`) enables web chat access. Deploy it to:
- Local: `python kb_mcp_server_http.py` (http://localhost:5000)
- Public: Deploy to Railway/Heroku/AWS and get public URL
- Then add URL to Claude settings

---

## CREDENTIALS LOCATION

**File:** `G:\My Drive\00 - Trajanus USA\00-Command-Center\05-Scripts\.env`

**Contents:**
```
SUPABASE_URL=https://iaxtwrswinygwwwdkvok.supabase.co
SUPABASE_SERVICE_KEY=[service_role key]
OPENAI_API_KEY=[api key for embeddings]
```

**IMPORTANT:** Claude instances in web chat CANNOT directly read .env files. Bill must provide credentials when needed.

---

## DATABASE STRUCTURE

**Table:** `knowledge_base`

**Schema:**
```sql
- id (uuid) - Primary key
- url (text) - Source location
- chunk_number (int) - Position in document
- title (text) - AI-generated summary
- summary (text) - AI-generated context
- content (text) - Actual text
- metadata (jsonb) - {source, category, crawl_date}
- embedding (vector 1536) - OpenAI embedding
- created_at (timestamp)
```

**Current Contents (1646 documents):**
- Session History: 1069 chunks (65%)
- Living Documents: 351 chunks (21%)
- Core Protocols: 216 chunks (13%)
- Website Content: 2 chunks (<1%)
- Other: 8 chunks (<1%)

---

## TYPICAL SEARCH QUERIES

**Finding recent work:**
```python
search_knowledge("December 9 accomplishments")
search_knowledge("RAG system implementation")
search_knowledge("MCP server HTTP bridge")
```

**Finding protocols:**
```python
search_knowledge("End of Session protocol")
search_knowledge("surgical edits only")
search_knowledge("token monitoring")
```

**Finding specific sessions:**
```python
recent_chats(n=10, after="2025-12-01")
search_knowledge("QCM workspace December 5")
```

---

## FOR TOM (End User)

Tom will NEVER interact with the knowledge base directly. He will use the **Trajanus Enterprise Hub** which has Claude embedded. The Hub makes API calls to Supabase in the background.

**Tom's experience:**
1. Opens Enterprise Hub
2. Opens QCM Workspace
3. Asks question: "What did we decide about submittal format?"
4. Hub → Claude → Supabase → Results → Tom sees answer

Tom sees clean interface. No databases. No scripts. Just answers.

---

## MAINTENANCE

**Adding new documents:**
```bash
cd "G:\My Drive\00 - Trajanus USA\00-Command-Center\05-Scripts"
python file_ingestion.py
```

**Checking database stats:**
```sql
SELECT 
  metadata->>'source' as source,
  COUNT(*) as count
FROM knowledge_base
GROUP BY metadata->>'source'
ORDER BY count DESC;
```

**Health check:**
```bash
python query_kb.py
# If it starts without errors, database is accessible
```

---

## TROUBLESHOOTING

**Problem:** Connection fails with 403 Forbidden  
**Solution:** Check SUPABASE_SERVICE_KEY in .env file - must be full JWT token, not abbreviated

**Problem:** No results from search  
**Solution:** Check if documents exist with `sources` command, adjust similarity threshold

**Problem:** Python script not found  
**Solution:** Verify path: `G:\My Drive\00 - Trajanus USA\00-Command-Center\05-Scripts\`

**Problem:** Web chat can't access APIs  
**Solution:** Network restrictions block external APIs from web chat - deploy HTTP server externally

---

## NEXT SESSION PROTOCOL

**When starting new Claude session:**

1. Search project knowledge for "HOW_TO_ACCESS_KB"
2. Read this file
3. If need to query knowledge base:
   - Ask Bill to run `query_kb.py` locally
   - OR if MCP configured, use directly
4. If building new features:
   - Reference this file for architecture
   - Use provided examples as patterns

---

**REMEMBER:** Knowledge base = permanent AI memory. Everything documented there persists across sessions and Claude instances. This is how we achieve true continuity.
