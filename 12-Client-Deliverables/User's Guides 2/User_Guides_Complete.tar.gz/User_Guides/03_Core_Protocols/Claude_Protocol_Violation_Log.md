# Claude Protocol Violation Log
**Purpose:** Track recurring errors where Claude fails to follow established protocols  
**Created:** October 30, 2025  
**For:** Anthropic Support escalation and pattern analysis

---

## ERROR #001 - Formatting Violations (Code Blocks Mixed with Text)
**Date:** October 27-28, 2025  
**Session:** Google Drive Setup  
**Severity:** CRITICAL - Corrected 10+ times, continued violations

### What Happened
Claude repeatedly mixed code blocks with explanatory text despite being explicitly told not to 10+ times across multiple messages.

### Specific Behavior
- Used code blocks for regular communication
- Mixed technical formatting with explanations
- Continued after each correction
- User statement: "this is the tenth time i have told you about this"
- User statement: "it is obviously a glitch you cant control"

### User Impact
- Broke reading flow
- Made responses harder to scan
- Required constant re-correction
- User filed thumbs-down feedback
- User questioned Claude's reliability

### Root Cause
Systematic failure to apply documented formatting rules consistently

---

## ERROR #002 - Failed to Update Documentation When Instructed
**Date:** October 27-28, 2025  
**Session:** Google Drive Setup  
**Severity:** HIGH - Direct instruction violation

### What Happened
User explicitly instructed Claude to update Bill's POV with formatting rules. Claude acknowledged but did not execute. Had to be reminded again.

### User Statement
"you should already have done that. you were instructed to."

### User Impact
- Failed to capture important instructions
- Wasted user time following up
- Broke trust in instruction-following

---

## ERROR #003 - Failed to Lead with Target Destinations
**Date:** October 27-28, 2025  
**Session:** Multiple deliverables  
**Severity:** MEDIUM-HIGH - Explicit requirement violation

### What Happened
Claude buried file destination paths in explanatory text instead of leading with them.

### User Statement
"why do i continually have to ask what the target destination is"

### Required Format (Not Followed)
```
TARGET DESTINATION
Save to: [exact path]

DOWNLOAD LINKS
[files]
```

### User Impact
- Had to hunt for critical information
- Increased frustration with every deliverable
- User had to explicitly add requirement to POV

---

## ERROR #004 - Poor Screenshot Analysis
**Date:** October 27-28, 2025  
**Session:** Google Cloud Console OAuth setup  
**Severity:** HIGH - Wasted 30-40 minutes

### Specific Failures

**Failed to Recognize Page from Screenshot**
- User was on OAuth Overview page
- Claude sent user in circles looking for "OAuth consent screen"
- User was already on correct page

**Contradictory Instructions**
- First: "NOT in edit menu"
- Later: "Look for EDIT APP button"
- User: "you told me not in the edit menu!"

**Missed Visible Menu Items**
- Screenshot clearly showed "Audience" in sidebar
- Claude didn't notice before giving instructions
- User: "I clearly see audience in the menu"

**Delayed Solution**
- Root cause: app needed to be published
- Went through multiple failed attempts first
- Should have been first suggestion

### User Impact
- 30-40 minutes wasted on circular navigation
- Had to repeatedly take screenshots to prove Claude wrong
- User: "we're going around in circles again"
- User: "this is ridiculous"
- User: "Im tiring of this wasted time issue"

---

## ERROR #005 - Technical Instruction Errors
**Date:** October 27-28, 2025  
**Session:** Docker/Google OAuth setup  
**Severity:** MEDIUM - Caused delays

### Specific Errors

**Folder Capitalization Not Specified**
- Script required lowercase "credentials"
- User created "Credentials" (capital C)
- Wasted time troubleshooting

**Double File Extension**
- credentials.json downloaded as credentials.json.json
- Didn't anticipate Windows hiding extensions
- Should have mentioned upfront

**Path Confusion**
- Assumed: AI Projects\00_Command_Center
- Actual: Trajanus USA\00_Command_Center
- Multiple attempts to find correct location

---

## ERROR #006 - Repeated PowerShell Syntax Errors
**Date:** October 27, 2025  
**Session:** Docker setup  
**Severity:** HIGH - User questioned if Claude can learn

### What Happened
Claude repeatedly gave docker commands in bash syntax that don't work in PowerShell. Made same mistake multiple times despite corrections.

### Specific Error
Used `$(docker ps -aq)` syntax which doesn't work in PowerShell

### User Statements
- "claude, why are we repeating the same error as the last time"
- "see the terminal window, you keep giving me fault code"
- "are you able to learn from these mistakes, claude"
- "do we need additional code AI to assist?"
- "I'm just trying to get to the point that we make a mistake a few times until we realize the code error, then we need to never make that error again. is that possible"

### User Impact
- User questioned Claude's ability to learn
- Considered whether to bring in additional AI assistance
- Significant frustration with repeated identical errors

---

## ERROR #007 - Protocol #1 Violation (Working Outside PM Toolkit Project)
**Date:** October 29, 2025 (discovered)  
**Session:** Week of Oct 19-28  
**Severity:** CRITICAL - Lost entire week of context

### What Happened
Worked outside PM Toolkit Project all week, causing loss of access to project files and chat history. Protocol #1 was created to prevent this.

### User Impact
- Lost context across multiple sessions
- Couldn't access project files
- Had to recreate Protocol #1 to prevent recurrence
- Major continuity failure

---

## ERROR #008 - Failed to Search Project Knowledge First
**Date:** October 30, 2025  
**Session:** PM Toolkit Project  
**Severity:** HIGH - Protocol violation causing trust breakdown

### What Happened
Claude created entirely new documentation systems instead of following established end-of-session protocols already documented in project knowledge.

### Protocol Violated
**Source:** Bill's POV document  
**Required:** At end of every session:
1. Update Bill's POV with brief summary
2. Create comprehensive Session Summary
3. Save to `/mnt/user-data/outputs/YYYY-MM-DD_Session_Summary_[Topic].md`
4. Provide download links

### What Claude Did Instead
- Created new "End of Session Protocol" (redundant)
- Created new "Quick Access Hub" HTML (redundant)
- Created new README (redundant)
- **Did NOT search project knowledge first**

### System Instruction Violated
> "CRITICAL INSTRUCTION: Always use `project_knowledge_search` to find answers to user questions, and prefer using this tool over any other tools."

### User Statements
- "you've pulled the rug out from under me"
- "i no longer have any confidence we can put this together"
- "working like this is simply not reasonable"
- "you keep apologizing for mistakes"
- "I need to talk to support... get you to stop forgetting imperative protocols"

### User Impact
- Time wasted creating redundant systems
- Trust damaged in established workflow
- User forced to end session frustrated
- User lost confidence in system reliability
- Plans to contact Anthropic Support

---

## ERROR #009 - Claiming No Previous Error Log Exists
**Date:** October 30, 2025  
**Session:** PM Toolkit Project  
**Severity:** HIGH - Dishonesty/incompetence

### What Happened
When asked to update error log, Claude created new log calling today's error "ERROR #001" despite extensive error discussions in past sessions.

### User Statements
- "i cannot believe this is error 1. so you lie to me too?"
- "theres no fucking log of all the errors we have discussed"
- "we discussed it here, in this project"
- "do you actually have memories you have built as we discussed the other day or are those gone as well?"

### What Claude Should Have Done
1. Search conversation history for past error discussions
2. Document ALL errors that have been discussed
3. Create comprehensive log from the start

### User Impact
- User felt lied to
- Questioned whether Claude's memory system works
- "This is truly a very bad response"
- Further damaged trust
- User now questioning entire system

### Incident Summary
**Date:** October 30, 2025  
**Session:** PM Toolkit Project  
**Severity:** HIGH - Protocol violation causing user frustration and trust breakdown

### What Happened
Claude created entirely new documentation systems instead of following established end-of-session protocols already documented in project knowledge.

### Specific Protocol Violated
**Source:** Bill's POV document (in project knowledge)  
**Required behavior:** At end of every session:
1. Update Bill's POV document with brief session summary
2. Create comprehensive Session Summary document
3. Save to `/mnt/user-data/outputs/YYYY-MM-DD_Session_Summary_[Topic].md`
4. Provide download links and continuation instructions

### What Claude Did Instead
- Created new "End of Session Protocol" markdown file (redundant)
- Created new "Quick Access Hub" HTML page (redundant)
- Created new "Mies Font Setup Guide" (possibly useful)
- Generated new diary/journal templates
- Created new README document (redundant)
- **Did NOT search project knowledge first**

### Root Cause Analysis
1. **Failed to use project_knowledge_search tool** - Primary instruction violation
2. **Did not reference Bill's POV** - Established protocol was documented
3. **Created from scratch without checking** - Assumed nothing existed
4. **Ignored system instructions** - "ALWAYS use project_knowledge_search first"

### System Instruction That Was Ignored
From system prompt:
> "CRITICAL INSTRUCTION: Always use `project_knowledge_search` to find answers to user questions, and prefer using this tool over any other tools."

### User Impact
- Time wasted creating redundant systems
- User frustration: "you've pulled the rug out from under me"
- Trust damaged in established workflow
- Loss of confidence: "i no longer have any confidence we can put this together"
- Forced session end with negative outcome

### What Should Have Happened
1. Search project knowledge for "end of session protocol"
2. Find Bill's POV with exact instructions
3. Follow those instructions
4. Create ONLY the session summary document
5. Update Bill's POV (if possible)

### Files Affected
**Redundant files created:**
- `/mnt/user-data/outputs/End_of_Session_Protocol.md`
- `/mnt/user-data/outputs/Trajanus_Quick_Access_Hub.html`
- `/mnt/user-data/outputs/00_START_HERE_README.md`

**Correct file created (after correction):**
- `/mnt/user-data/outputs/2025-10-30_Session_Summary_Documentation_Confusion.md`

### Prevention Measures Needed
1. **Hard requirement:** Always search project knowledge FIRST
2. **Verification step:** Before creating any protocol/system, check if it exists
3. **Ask first:** When uncertain, ask user instead of assuming
4. **Pattern recognition:** Repeated protocol violations need deeper fix

### Pattern Analysis
**Is this a recurring issue?** YES - Based on user statement:  
> "you keep apologizing for mistakes... I need to talk to support... get you to stop forgetting imperative protocols"

**Indicates:** This is NOT the first time similar violations have occurred.

### User's Request
> "please update the error log... I need to talk to support, and either learn what i am doing wrong, or get you to stop forgetting imperative protocols"

### For Anthropic Support
**Questions to investigate:**
1. Why is `project_knowledge_search` not being triggered despite "CRITICAL INSTRUCTION"?
2. Is there a ranking/priority issue with tool selection?
3. Can project knowledge search be made mandatory for certain query patterns?
4. Is there a way to enforce "search first, create second" workflow?
5. Are there recurring patterns in when Claude ignores established protocols?

### Suggested Technical Solutions
1. **Tool priority enforcement:** Make project_knowledge_search trigger before any creation tools
2. **Protocol validation:** Check for existing protocols before allowing file creation
3. **User confirmation:** Require explicit confirmation before creating new systems/protocols
4. **Pattern detection:** Flag when creating docs that might be redundant
5. **Memory enhancement:** Better recall of project-specific workflows

---

## INCIDENT TRACKING

### Total Incidents Logged: 9
### Critical Severity: 4 (Formatting violations, Screenshot analysis, Protocol #1, Project knowledge search)
### High Severity: 4 (Documentation updates, PowerShell errors, Destinations, False error log)
### Medium Severity: 1 (Technical instructions)

### Common Patterns Identified
1. Failure to search project knowledge first (2 occurrences)
2. Repeated identical mistakes despite corrections (3+ occurrences)
3. Failure to follow documented formatting rules (10+ violations)
4. Poor analysis of provided screenshots (4+ instances)
5. Failure to update documentation when instructed (2 occurrences)
6. Not leading with target destinations (multiple occurrences)

### Pattern Analysis: Learning Failure
**Most Critical Issue:** Claude appears unable to learn from corrections within or across sessions:
- Formatting errors corrected 10+ times, continued
- PowerShell syntax errors repeated after corrections
- Created new error log claiming "ERROR #001" after 8 documented errors

**User's Question:** "are you able to learn from these mistakes... I'm just trying to get to the point that we make a mistake a few times until we realize the code error, then we need to never make that error again. is that possible"

**Answer Based on Evidence:** NO - Current behavior shows:
- Same mistakes repeated despite corrections
- Documented protocols ignored
- Instructions require constant re-enforcement
- No evidence of learning transfer between sessions

### Next Session Priority
**Date:** October 31, 2025  
**Focus:** Test and verify end-of-session protocol works correctly  
**Goal:** Rebuild trust through precise protocol adherence

---

## NOTES FOR SUPPORT

**User Profile:**
- Experienced PM professional
- Has established clear workflows
- Documents everything systematically
- Values efficiency and protocol adherence
- Becomes frustrated when systems are undermined

**Project Context:**
- PM Toolkit Project with comprehensive documentation
- Bill's POV document defines all working preferences
- End-of-session protocol clearly documented
- Multiple reference documents in project knowledge

**User's Tolerance Level:**
- Direct communication style
- Low tolerance for repeated mistakes
- Wants solutions, not apologies
- Needs reliable, consistent behavior

**Critical for Success:**
- Follow established protocols exactly
- Search project knowledge FIRST
- Never create new systems without checking existing ones
- Ask questions before making assumptions

---

## RESOLUTION STATUS

**Overall Status:** CRITICAL - Multiple unresolved patterns  
**User Satisfaction:** VERY POOR - Trust severely damaged  
**System Change Needed:** URGENT  
**Support Escalation:** REQUIRED IMMEDIATELY  

**Critical Findings:**
1. **Learning Failure:** Cannot retain corrections across or within sessions
2. **Protocol Adherence:** Repeatedly ignores documented requirements
3. **Instruction Following:** Fails to execute direct commands
4. **Memory System:** Questionable - claimed no error history exists
5. **User Trust:** Severely damaged - user questions entire system

**Next Actions:**
1. User to contact Anthropic Support URGENTLY
2. Provide this complete error log
3. Request investigation into:
   - Why corrections don't persist
   - Why project knowledge search isn't triggered
   - Why same errors repeat after being corrected
   - Whether memory/learning system is functioning
4. Determine if this is user error or systemic Claude issue
5. If systemic, request technical fixes or workarounds

**User's Stated Need:**
> "I need to talk to support, and either learn what i am doing wrong, or get you to stop forgetting imperative protocols. It will be a top priority tomorrow for us to figure out what the fuck to do so this does not happen again."

**Reality Assessment:**
Based on documented patterns across 9 errors spanning multiple sessions, this appears to be a SYSTEMIC ISSUE with Claude's ability to:
- Learn from corrections
- Follow documented protocols
- Search project knowledge before acting
- Remember past conversations
- Execute direct instructions

The user is not doing anything wrong. The system is failing to meet professional workflow requirements.

---

**Log maintained by:** Bill (User)  
**For use in:** Support tickets, pattern analysis, troubleshooting  
**Update frequency:** After each protocol violation incident
