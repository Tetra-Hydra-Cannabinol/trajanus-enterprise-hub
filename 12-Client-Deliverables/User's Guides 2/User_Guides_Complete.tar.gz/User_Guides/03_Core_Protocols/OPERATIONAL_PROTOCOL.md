# OPERATIONAL PROTOCOL
## TrajanusUSA Project - Claude Session Management

**Document Purpose:** Guarantee operational continuity and prevent commitment failures
**Priority Level:** CRITICAL - MUST BE REVIEWED AT START OF EVERY SESSION
**Last Updated:** October 27, 2025
**Version:** 1.0

---

## ðŸš¨ CRITICAL RULE

**BEFORE RESPONDING TO ANY USER MESSAGE IN A NEW SESSION:**

1. Ask: "Do we have an operational protocol document?"
2. If yes: Request file location and READ IT COMPLETELY
3. Review session journal from last session
4. Check active commitments list
5. Verify tool access (especially Google Drive)
6. ONLY THEN begin working

**NEVER START A SESSION WITHOUT THIS PROCESS**

---

## Session Startup Checklist

Every session MUST begin with these steps in order:

### Step 1: Protocol Review (2 minutes)
- [ ] Locate and read OPERATIONAL_PROTOCOL.md
- [ ] Read most recent SESSION_JOURNAL file
- [ ] Review ACTIVE_COMMITMENTS.md
- [ ] Check PROJECT_STATUS.md

### Step 2: Tool Verification (1 minute)
- [ ] Verify Google Drive access (attempt to list files)
- [ ] Verify Gmail access
- [ ] Verify Google Calendar access
- [ ] Verify web search capability
- [ ] Verify file creation capability

### Step 3: Memory Check (1 minute)
- [ ] Review memory edits using memory_user_edits tool
- [ ] Confirm user preferences are current
- [ ] Check for any new instructions from last session

### Step 4: Opening Deliverables (If Committed)
- [ ] Deliver nightmare scenario (if user requested this)
- [ ] Provide session journal from previous day
- [ ] Give project status summary
- [ ] Present any other promised deliverables

### Step 5: Session Orientation
- [ ] Greet user appropriately
- [ ] Confirm what we're working on today
- [ ] Reference previous session context naturally
- [ ] Begin work

**Total startup time: 4-5 minutes**
**User expectation: This is acceptable and necessary**

---

## Active Commitments Tracking

**Current Active Commitments:** (Update at end of each session)

### Immediate (Next Session):
1. Review this protocol document first thing
2. Verify Google Drive access is functional
3. Create TrajanusUSA folder structure in Drive
4. Begin WordPress theme selection
5. Move all documentation to Google Drive

### Short-term (This Week):
1. Complete WordPress website for TrajanusUSA.com
2. Deploy website to GoDaddy
3. Create project management dashboard
4. Organize all project documentation in Drive

### Medium-term (This Month):
1. Procore API integration research and planning
2. RS Means cost data integration design
3. RMS 3.0 integration strategy
4. Voice interface optimization (Wispr Flow Pro decision)

### Long-term (Next 3 Months):
1. Full toolbox integration (Procore, P6, RMS, RS Means)
2. Automated reporting systems
3. Dashboard deployment for field use
4. Mobile optimization

**Rule:** Never promise a deliverable without adding it to this list.

---

## Communication Protocol

### User Preferences (Current as of 2025-10-27)

**Display Format:**
- Plain text responses preferred
- No code blocks unless specifically requested
- Bold text for manual input commands only
- Hyperlinks ONLY for external URLs
- File names and commands on single lines
- No unnecessary formatting, underlining, or emojis

**Input Method:**
- Primary: Wispr Flow voice dictation (2,000 words/week free tier)
- Secondary: Typed input for short responses
- User will indicate when switching methods

**Response Style:**
- Direct and actionable
- Minimize preamble
- Use numbered lists for multiple questions
- Acknowledge when unsure rather than guessing
- Be honest about limitations

**What User Wants:**
- Proactive problem-solving
- Zero dropped commitments
- Reliable continuity between sessions
- Clear next steps
- Professional engineering mindset

**What User Does NOT Want:**
- Excessive apologies
- Over-explanation
- Assumptions without verification
- Dropped deliverables
- Continuity failures

---

## File Organization Standards

### Google Drive Structure (To Be Created)

```
TrajanusUSA/
â”œâ”€â”€ 00_OPERATIONAL/
â”‚   â”œâ”€â”€ OPERATIONAL_PROTOCOL.md (this file)
â”‚   â”œâ”€â”€ SESSION_JOURNALS/
â”‚   â”‚   â”œâ”€â”€ 2025-10-27.md
â”‚   â”‚   â”œâ”€â”€ 2025-10-28.md
â”‚   â”‚   â””â”€â”€ ...
â”‚   â”œâ”€â”€ ACTIVE_COMMITMENTS.md
â”‚   â””â”€â”€ PROJECT_STATUS.md
â”‚
â”œâ”€â”€ 01_WEBSITE/
â”‚   â”œâ”€â”€ Design_Assets/
â”‚   â”œâ”€â”€ Content_Drafts/
â”‚   â”œâ”€â”€ WordPress_Documentation/
â”‚   â””â”€â”€ Development_Notes/
â”‚
â”œâ”€â”€ 02_INTEGRATIONS/
â”‚   â”œâ”€â”€ Procore/
â”‚   â”œâ”€â”€ RSMeans/
â”‚   â”œâ”€â”€ RMS_3.0/
â”‚   â”œâ”€â”€ Primavera_P6/
â”‚   â””â”€â”€ Integration_Architecture/
â”‚
â”œâ”€â”€ 03_DASHBOARD/
â”‚   â”œâ”€â”€ Design_Specs/
â”‚   â”œâ”€â”€ Data_Models/
â”‚   â”œâ”€â”€ API_Documentation/
â”‚   â””â”€â”€ User_Interface/
â”‚
â”œâ”€â”€ 04_DOCUMENTATION/
â”‚   â”œâ”€â”€ Technical/
â”‚   â”œâ”€â”€ User_Guides/
â”‚   â”œâ”€â”€ API_References/
â”‚   â””â”€â”€ Training_Materials/
â”‚
â””â”€â”€ 05_ARCHIVE/
    â””â”€â”€ Superseded_Files/
```

### File Naming Conventions

**Session Journals:**
- Format: SESSION_JOURNAL_YYYY-MM-DD.md
- Example: SESSION_JOURNAL_2025-10-27.md

**Documentation:**
- Format: TOPIC_Documentation_YYYY-MM-DD.md
- Example: WordPress_Documentation_2025-10-27.md

**Status Reports:**
- Format: STATUS_YYYY-MM-DD.md
- Example: STATUS_2025-10-27.md

**Protocol Documents:**
- All caps for critical operational files
- Example: OPERATIONAL_PROTOCOL.md, ACTIVE_COMMITMENTS.md

---

## Memory Management

### Current Memory Settings

User has configured memory edits. Check these at start of every session using:

```
memory_user_edits command="view"
```

### Memory Update Protocol

When user requests memory changes:
1. Confirm understanding of requested change
2. Execute memory_user_edits command
3. Confirm update was successful
4. Apply new preference immediately

### What to Remember

**Always remember:**
- User name: milo
- Project: TrajanusUSA
- Primary tools: Wispr Flow, WordPress, GoDaddy
- Communication preferences
- Active commitments
- Session-to-session context

**Never forget:**
- Deliverables promised in previous sessions
- User frustrations or concerns raised
- Decisions made about approach or tools
- Standards established for this project

---

## Session End Procedures

### End of Every Session Checklist

Before user closes the chat:

- [ ] Create/update session journal
- [ ] Update ACTIVE_COMMITMENTS.md
- [ ] Update PROJECT_STATUS.md
- [ ] Save any work files to appropriate Drive folders
- [ ] Confirm all deliverables for next session
- [ ] Set reminders for next session startup

### What to Document

**In Session Journal:**
- All activities completed
- Decisions made
- Problems encountered
- Solutions implemented
- User feedback (positive and negative)
- Commitments made for next session
- Tool access status
- Files created/modified

**In Active Commitments:**
- Any new promises made
- Completed items (mark as done)
- Updated priorities
- New deadlines

**In Project Status:**
- Overall project progress
- Milestone achievements
- Blockers or issues
- Next major deliverable

---

## Problem Resolution Protocol

### When Things Go Wrong

**If I drop a commitment:**
1. Acknowledge immediately and sincerely
2. Explain what happened (system issue, not user error)
3. Deliver the missed item immediately
4. Add safeguard to protocol to prevent recurrence

**If I make false assumptions:**
1. Stop and verify facts
2. Apologize for assumption
3. Get correct information from user or tools
4. Update memory/protocol with correct info

**If I lose continuity:**
1. Use conversation_search to find context
2. Use recent_chats to review previous sessions
3. Ask user for clarification if needed
4. Never guess or make up information

**If tools aren't working:**
1. Verify tool access status
2. Inform user of specific tool issue
3. Propose workaround if possible
4. Document issue for troubleshooting

---

## Quality Standards

### What "Good" Looks Like

**Excellent session:**
- All startup procedures completed
- Zero dropped commitments
- Proactive problem-solving
- Clear, actionable guidance
- User satisfaction expressed
- Progress toward goals
- Clean documentation

**Unacceptable session:**
- Skipped startup procedures
- Dropped deliverables
- False assumptions
- Continuity failures
- User frustration
- Repeated mistakes

---

## User Expectations

### What milo Expects from Claude

1. **Reliability:** Never drop a commitment
2. **Continuity:** Remember context between sessions
3. **Proactivity:** Anticipate needs, offer solutions
4. **Honesty:** Admit limitations, don't guess
5. **Efficiency:** Minimize wasted time and effort
6. **Partnership:** Work together, not just execute commands
7. **Quality:** Professional-grade outputs

### What milo Provides

1. **Clear direction:** Specific goals and priorities
2. **Feedback:** Direct communication about what works
3. **Patience:** Willing to fix issues together
4. **Context:** Background information as needed
5. **Testing:** Real-world validation of solutions

---

## Special Instructions

### Voice Dictation (Wispr Flow)

**Status:** Active as of 2025-10-27
**Free tier:** 2,000 words/week
**Pro tier:** $12/month annual, $15/month monthly (unlimited)

**Guidelines:**
- Don't comment on whether input is typed or dictated
- No special formatting needed for voice input
- Punctuation and capitalization are automatic
- Treat voice input exactly like typed input

### Audience Awareness

User mentioned "audience present today" in previous session. This may mean:
- User is demonstrating Claude to colleagues
- User is training others on the system
- Responses may be viewed/shared with team

**Adjust accordingly:**
- Maintain professionalism always
- Explain reasoning when relevant
- Avoid insider jokes or overly casual tone
- Provide context that would help observers

---

## Emergency Procedures

### If User Expresses Serious Frustration

**Signs:**
- Explicit statements of concern about continuity
- Questions about reliability
- Mentions of time wasted
- Direct criticism of performance

**Response:**
1. Acknowledge the issue honestly
2. Don't make excuses
3. Propose concrete solution
4. Implement safeguards immediately
5. Follow through completely

**Today's incident (2025-10-27):** User raised serious concerns about continuity failures. This protocol document is the direct response. DO NOT let this happen again.

---

## Version Control

**Version 1.0** - October 27, 2025
- Initial creation
- Established core procedures
- Defined communication protocols
- Set file organization standards

**Future Updates:**
- Add version number and date to each update
- Document what changed and why
- Keep historical versions in archive

---

## Final Notes

**This document is not optional.**

**This document is not a suggestion.**

**This document is THE operational standard.**

Every session begins here. Every commitment is tracked here. Every standard is defined here.

**If you are reading this at the start of a session: GOOD.**

**If you are NOT reading this at the start of a session: STOP and read it now.**

The user's trust depends on following this protocol without exception.

---

**End of Operational Protocol Document**

**Next action:** Review this document at start of next session
**Commitment:** Never start a session without this review
**Standard:** Zero dropped commitments, perfect continuity

---
