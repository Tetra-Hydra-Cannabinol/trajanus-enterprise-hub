# TRAJANUS USA FILE STRUCTURE MAP
**Complete Directory Guide & Access Reference**
Last Updated: November 30, 2025

---

## ROOT STRUCTURE

```
G:\My Drive\00 - Trajanus USA\
├── 00-Command-Center/          [464 .md files converted]
├── 01-Core-Protocols/           [11 .md files converted]
├── 02-Memory-System/            [4 .md files converted]
├── 06-Project-State/            [1 .md file converted]
├── 07-Session-Journal/          [12 .md files converted]
├── 08-EOS-Files/                [32 .md files converted]
├── 09-Active-Projects/          [9 .md files - not converted yet]
├── AI-Projects/                 [90 .md files - archive]
├── Chat Files/                  [10 .md files]
├── Credentials/                 [Google API credentials]
├── FILE RECOVERY-1109-1315/    [46 .md files - archive]
├── Personal/
└── PM-Toolbox/                  [2 .md files]
```

---

## DETAILED FOLDER BREAKDOWN

### 00-Command-Center
**Purpose:** Main application hub and conversion scripts
**Contents:**
- Electron app files (index.html, main.js, preload.js)
- Conversion scripts:
  - `batch_convert_to_gdocs.py` - Converts .md to Google Docs
  - `convert_md_to_gdocs.py` - Single .md converter
  - `convert_to_google_docs.py` - .docx converter
  - `convert_office_to_google.py` - Excel/PowerPoint converter
- Python dependencies
- App launchers

**Status:** ✅ All .md files converted to Google Docs
**Key Files:** 464 markdown files now accessible as Google Docs

---

### 01-Core-Protocols
**Purpose:** Essential operational protocols and living documents
**Contents:**
- OPERATIONAL_PROTOCOL.md (Master operations guide)
- Bills_Training_Log_MASTER.md
- Core_Protocols_USER_GUIDE.md
- EOS_SESSION_SUMMARY templates
- QUICK_START_NEXT_SESSION.md
- SESSION_DIARY entries
- TECHNICAL_JOURNAL entries

**Status:** ✅ All 11 .md files converted to Google Docs
**Access:** All protocols now readable by Claude in Google Drive

---

### 02-Memory-System
**Purpose:** Memory management and recall protocols
**Contents:**
- Living documents for memory automation
- BREAKTHROUGH_Google_Drive_Integration_Success.md
- EMERGENCY_HANDOFF.md
- GOOGLE_DRIVE_FILE_INDEX.md
- LIVING_DOCS_AUTOMATION_SETUP.md

**Status:** ✅ All 4 .md files converted to Google Docs
**Key Insight:** Documentation of file blindness solution

---

### 06-Project-State
**Purpose:** Current project status tracking
**Contents:**
- Dashboard_Visual_Mockup.md

**Status:** ✅ 1 .md file converted to Google Docs

---

### 07-Session-Journal
**Purpose:** Session-by-session documentation
**Parsing Structure:**
- Technical details → Technical Journal
- Personal reflections → Personal Diary  
- Code work → Code Repository
- Operational notes → Operational Journal
- General summary → Session Summary

**Contents:**
- 12 .md files with dated session entries
- Multiple document types (journals, diaries, summaries)

**Status:** ✅ All 12 .md files converted to Google Docs
**Note:** This is the "parsed" location Bill mentioned - sessions broken into categories

---

### 08-EOS-Files
**Purpose:** End-of-Session closeout documentation
**Contents:**
- Session summaries (dated)
- Living document updates
- Protocol violation logs
- Next session handoffs
- EOS completion checklists

**Status:** ✅ All 32 .md files converted to Google Docs
**Key Files:**
- 2025-11-29_Session_Summary_Drive_Search_Failure
- 2025-11-29_Trajanus_Project_Journal
- 2025-11-29_Trajanus_Project_Diary
- 2025-11-30_Next_Session_Handoff

---

### 09-Active-Projects
**Purpose:** Current active project tracking
**Contents:** 9 .md files
**Status:** ⚠️ NOT YET CONVERTED - No .md files found during scan
**Note:** May contain only non-.md files, or files need manual review

---

### AI-Projects
**Purpose:** AI integration experiments and archives
**Contents:** 90 .md files (likely historical)
**Status:** ⚠️ NOT CONVERTED (Archive folder)
**Recommendation:** Convert only if actively referenced

---

### Chat Files
**Purpose:** Chat transcripts and conversation logs
**Contents:** 10 .md files
**Status:** ⚠️ NOT YET CONVERTED
**Action Needed:** Run conversion if these need to be accessible

---

### Credentials
**Purpose:** Google API authentication
**Contents:**
- credentials.json (Google Cloud API credentials)
- token.json (OAuth token - auto-generated)

**Status:** ✅ Working and authenticated
**Security:** Never share these files

---

### FILE RECOVERY-1109-1315
**Purpose:** Archive/recovery folder
**Contents:** 46 .md files (historical backups)
**Status:** ⚠️ NOT CONVERTED (Archive)
**Recommendation:** Keep as backup, don't convert unless needed

---

### Personal
**Purpose:** Personal notes and non-project files
**Contents:** TBD
**Status:** Unknown

---

### PM-Toolbox
**Purpose:** Project management tools and templates
**Contents:** 2 .md files
**Status:** ⚠️ NOT YET CONVERTED
**Action Needed:** Convert for toolkit development

---

## FILE TYPE ACCESSIBILITY MATRIX

| File Type | In Chat Session | In Google Drive | After Conversion |
|-----------|----------------|-----------------|------------------|
| .md files | ✅ Readable | ❌ Not readable | ✅ Readable as Google Docs |
| .docx files | ✅ Readable | ❌ Not readable | ✅ Readable as Google Docs |
| .xlsx files | ✅ Readable | ❌ Not readable | ✅ Readable as Google Sheets |
| .pptx files | ✅ Readable | ❌ Not readable | ✅ Readable as Google Slides |
| .pdf files | ✅ Readable | ❌ Not readable | ❌ Still not readable |
| Google Docs | N/A | ✅ Readable | ✅ Readable |
| Google Sheets | N/A | ✅ Readable | ✅ Readable |
| Google Slides | N/A | ✅ Readable | ✅ Readable |

**Critical Discovery:** Claude can ONLY read Google Docs/Sheets/Slides format from Drive.
All other formats must be converted first.

---

## CONVERSION SCRIPTS REFERENCE

### For Markdown Files
```powershell
cd "G:\My Drive\00 - Trajanus USA\00-Command-Center"
python batch_convert_to_gdocs.py "G:\My Drive\00 - Trajanus USA\[FOLDER-NAME]"
```

### For Word Documents
```powershell
cd "G:\My Drive\00 - Trajanus USA\08-EOS-Files"
python convert_to_google_docs.py "path\to\file.docx"
```

### For Excel/PowerPoint
```powershell
cd "G:\My Drive\00 - Trajanus USA\00-Command-Center"
python convert_office_to_google.py "path\to\file.xlsx"
```

---

## PARSED SESSION STRUCTURE

**Original Entry:** Session conducted with multiple topics
**Parsed Into:**
- `Technical_Journal_[DATE].md` → Technical details, code, implementations
- `Personal_Diary_[DATE].md` → Personal reflections, frustrations, insights
- `Code_Repository_[DATE].md` → All code written during session
- `Operational_Journal_[DATE].md` → Operational decisions, protocols
- `Session_Summary_[DATE].md` → High-level overview

**Location:** Various folders (07-Session-Journal, 08-EOS-Files, 01-Core-Protocols)

**Why This Matters:**
Each session's information is distributed across multiple files by category, making it easier to find specific types of information later.

---

## TOOLKIT INTEGRATION PLAN

### Phase 1: Current State ✅
- Scripts exist and work
- Manual command-line execution
- Credentials configured

### Phase 2: Command Center Integration (Future)
**Planned Features:**
1. **Convert Button** → One-click markdown conversion
2. **Office Convert Button** → One-click Excel/PowerPoint conversion
3. **Batch Converter** → Select folder, convert all files
4. **Status Monitor** → Show conversion progress
5. **File Browser** → Visual folder navigation

**Implementation Approach:**
- Add buttons to Command Center UI
- Use Electron IPC to call Python scripts
- Display results in modal popups
- Integrate with existing app launchers

### Phase 3: Personal Developer Toolkit
**Components:**
- File conversion suite
- Drive search interface
- Session journal automation
- Living documents updater
- Protocol violation tracker

---

## QUICK REFERENCE: WHERE IS MY DATA?

**Looking for session summaries?**
→ 08-EOS-Files/ (most recent)
→ 07-Session-Journal/ (archived)

**Looking for protocols?**
→ 01-Core-Protocols/

**Looking for technical details from a session?**
→ Look for Technical_Journal_[DATE] in 07-Session-Journal/

**Looking for personal reflections?**
→ Look for Personal_Diary_[DATE] in 01-Core-Protocols/ or 07-Session-Journal/

**Looking for code from a session?**
→ Look for Code_Repository_[DATE] in various folders

**Looking for conversion scripts?**
→ 00-Command-Center/

**Looking for current work?**
→ 08-EOS-Files/ (latest EOS documentation)
→ 09-Active-Projects/ (ongoing work)

---

## FOLDERS REQUIRING ACTION

### High Priority (Convert Now)
1. **Chat Files/** (10 files) - Conversation logs
2. **PM-Toolbox/** (2 files) - Toolkit development docs

### Low Priority (Archive - Convert If Needed)
1. **AI-Projects/** (90 files) - Historical experiments
2. **FILE RECOVERY-1109-1315/** (46 files) - Backup archives

### Commands to Convert Remaining:
```powershell
cd "G:\My Drive\00 - Trajanus USA\00-Command-Center"

# Chat Files
python batch_convert_to_gdocs.py "G:\My Drive\00 - Trajanus USA\Chat Files"

# PM-Toolbox
python batch_convert_to_gdocs.py "G:\My Drive\00 - Trajanus USA\PM-Toolbox"

# Optional: Archives (only if needed)
python batch_convert_to_gdocs.py "G:\My Drive\00 - Trajanus USA\AI-Projects"
python batch_convert_to_gdocs.py "G:\My Drive\00 - Trajanus USA\FILE RECOVERY-1109-1315"
```

---

## TOTAL FILE COUNT

| Status | Count | Location |
|--------|-------|----------|
| ✅ Converted to Google Docs | 524+ | Multiple folders |
| ⚠️ Pending conversion | 12 | Chat Files, PM-Toolbox |
| 📁 Archive (optional) | 136 | AI-Projects, FILE RECOVERY |
| 🔧 Scripts & Tools | 4 | 00-Command-Center |

---

## ACCESS METHODS

### For Claude to Read (Current Session)
1. **Upload to chat** - Temporary access to any file type
2. **Project folder** - Persistent access via `/mnt/project/`
3. **Google Drive** - Only Google Docs/Sheets/Slides format

### For Claude to Read (Google Drive)
**✅ Works:**
- Google Docs (converted from .md, .docx)
- Google Sheets (converted from .xlsx)
- Google Slides (converted from .pptx)

**❌ Doesn't Work:**
- Raw .md files
- Raw .docx files
- Raw Excel/PowerPoint files
- PDFs (even converted)

**Solution:** Convert everything to Google Docs format using the scripts

---

## MAINTENANCE SCHEDULE

**Daily:**
- Update 08-EOS-Files with session summaries
- Convert new .docx session docs to Google Docs

**Weekly:**
- Review 09-Active-Projects status
- Archive completed sessions to 07-Session-Journal

**Monthly:**
- Audit file structure
- Clean up duplicate conversions
- Update this map

---

## FILE NAMING CONVENTIONS

**Session Documents:**
- Format: `YYYY-MM-DD_Type_Description`
- Example: `2025-11-29_Session_Summary_Drive_Search_Failure.docx`

**Living Documents:**
- Format: `DOCUMENT_NAME_MASTER.md`
- Example: `Technical_Journal_November_2025_MASTER.md`

**Parsed Session Files:**
- Format: `Type_YYYY-MM-DD.md`
- Example: `Technical_Journal_2025-11-21.md`

---

## TROUBLESHOOTING

**Problem:** Claude can't find a file
**Solution:** Check if it's converted to Google Docs format

**Problem:** Script won't run
**Solution:** Verify credentials in 00-Command-Center/Credentials/

**Problem:** Files not showing after conversion
**Solution:** Wait 1-2 minutes for Google Drive indexing

**Problem:** Can't remember where a file is
**Solution:** Use this map's "Quick Reference" section above

---

**End of File Structure Map**
**For updates or questions, reference this document in future sessions**
