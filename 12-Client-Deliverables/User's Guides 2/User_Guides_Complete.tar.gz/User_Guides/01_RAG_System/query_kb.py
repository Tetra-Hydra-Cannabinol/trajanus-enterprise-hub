"""
TRAJANUS KNOWLEDGE BASE QUERY TOOL
Any Claude instance can run this to query the knowledge base
"""

import os
import sys
from pathlib import Path
from dotenv import load_dotenv
from openai import OpenAI
from supabase import create_client, Client
import json

# Load environment
env_path = Path(__file__).parent.parent / '.env'
load_dotenv(env_path)

# Initialize clients
supabase: Client = create_client(
    os.getenv('SUPABASE_URL'),
    os.getenv('SUPABASE_SERVICE_KEY')
)

openai_client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))

def search_knowledge(query: str, limit: int = 5, threshold: float = 0.3):
    """
    Search knowledge base with semantic similarity
    
    Args:
        query: Natural language search query
        limit: Maximum results to return
        threshold: Minimum similarity score (0-1)
    
    Returns:
        List of relevant documents with similarity scores
    """
    
    print(f"\n🔍 Searching knowledge base for: '{query}'")
    print(f"{'='*70}\n")
    
    # Generate embedding for query
    try:
        response = openai_client.embeddings.create(
            input=query,
            model="text-embedding-3-small"
        )
        query_embedding = response.data[0].embedding
    except Exception as e:
        print(f"❌ Error generating embedding: {e}")
        return []
    
    # Search database using vector similarity
    try:
        # Call the match_knowledge_base function
        result = supabase.rpc(
            'match_knowledge_base',
            {
                'query_embedding': query_embedding,
                'match_threshold': threshold,
                'match_count': limit
            }
        ).execute()
        
        docs = result.data
        
        if not docs:
            print("❌ No results found")
            return []
        
        print(f"✅ Found {len(docs)} results:\n")
        
        for i, doc in enumerate(docs, 1):
            similarity = doc.get('similarity', 0) * 100
            print(f"Result {i}:")
            print(f"  Title: {doc['title']}")
            print(f"  Similarity: {similarity:.1f}%")
            print(f"  Source: {doc['metadata'].get('source', 'Unknown')}")
            print(f"  Content Preview: {doc['content'][:150]}...")
            print()
        
        return docs
        
    except Exception as e:
        print(f"❌ Search error: {e}")
        return []

def get_recent_sessions(limit: int = 5):
    """Get most recent session documents"""
    
    print(f"\n📅 Retrieving {limit} most recent sessions")
    print(f"{'='*70}\n")
    
    try:
        result = supabase.table('knowledge_base')\
            .select('*')\
            .eq('metadata->>source', 'Session History')\
            .order('created_at', desc=True)\
            .limit(limit)\
            .execute()
        
        docs = result.data
        
        if not docs:
            print("❌ No sessions found")
            return []
        
        print(f"✅ Found {len(docs)} sessions:\n")
        
        for i, doc in enumerate(docs, 1):
            print(f"Session {i}:")
            print(f"  Title: {doc['title']}")
            print(f"  Date: {doc['created_at'][:10]}")
            print(f"  Preview: {doc['content'][:150]}...")
            print()
        
        return docs
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return []

def get_by_source(source: str, limit: int = 10):
    """Get documents from specific source"""
    
    print(f"\n📂 Retrieving documents from: {source}")
    print(f"{'='*70}\n")
    
    try:
        result = supabase.table('knowledge_base')\
            .select('*')\
            .eq('metadata->>source', source)\
            .order('created_at', desc=True)\
            .limit(limit)\
            .execute()
        
        docs = result.data
        
        if not docs:
            print(f"❌ No documents found for source: {source}")
            return []
        
        print(f"✅ Found {len(docs)} documents:\n")
        
        for i, doc in enumerate(docs, 1):
            print(f"Document {i}:")
            print(f"  Title: {doc['title']}")
            print(f"  Preview: {doc['content'][:100]}...")
            print()
        
        return docs
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return []

def list_sources():
    """List all available knowledge sources"""
    
    print(f"\n🗂️  Available Knowledge Sources")
    print(f"{'='*70}\n")
    
    try:
        result = supabase.table('knowledge_base')\
            .select('metadata')\
            .execute()
        
        sources = {}
        for doc in result.data:
            source = doc.get('metadata', {}).get('source', 'Unknown')
            sources[source] = sources.get(source, 0) + 1
        
        for source, count in sorted(sources.items(), key=lambda x: x[1], reverse=True):
            print(f"  {source}: {count} chunks")
        
        print()
        
    except Exception as e:
        print(f"❌ Error: {e}")

def main():
    """Interactive query interface"""
    
    if len(sys.argv) > 1:
        # Command line mode - join all args as query
        query = ' '.join(sys.argv[1:])
        # Remove 'search' if it's the first word
        if query.lower().startswith('search '):
            query = query[7:]
        search_knowledge(query)
    else:
        # Interactive mode
        print("\n" + "="*70)
        print("TRAJANUS KNOWLEDGE BASE - QUERY TOOL")
        print("="*70)
        
        print("\nCommands:")
        print("  search <query>  - Semantic search")
        print("  recent          - Show recent sessions")
        print("  sources         - List all sources")
        print("  source <name>   - Get docs from source")
        print("  exit            - Quit")
        print()
        
        while True:
            try:
                cmd = input("\nQuery> ").strip()
                
                if not cmd:
                    continue
                
                if cmd.lower() == 'exit':
                    print("\n👋 Goodbye!\n")
                    break
                
                parts = cmd.split(maxsplit=1)
                command = parts[0].lower()
                
                if command == 'search' and len(parts) > 1:
                    search_knowledge(parts[1])
                
                elif command == 'recent':
                    get_recent_sessions()
                
                elif command == 'sources':
                    list_sources()
                
                elif command == 'source' and len(parts) > 1:
                    get_by_source(parts[1])
                
                else:
                    # Default to search
                    search_knowledge(cmd)
                
            except KeyboardInterrupt:
                print("\n\n👋 Goodbye!\n")
                break
            except Exception as e:
                print(f"\n❌ Error: {e}\n")

if __name__ == "__main__":
    main()
