#!/usr/bin/env python3
"""
convert_md_to_gdocs.py - Convert markdown files to Google Docs
Finds markdown files in Google Drive and converts them to Google Docs format
"""

import os
import json
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseDownload
import io

# File locations
CREDENTIALS_FILE = 'credentials.json'
TOKEN_FILE = 'token.json'

def get_services():
    """Initialize and return Google Drive and Docs services"""
    if not os.path.exists(TOKEN_FILE):
        print("❌ token.json not found. Please authenticate first.")
        return None, None
    
    with open(TOKEN_FILE, 'r') as token_file:
        token_data = json.load(token_file)
    
    creds = Credentials.from_authorized_user_info(token_data)
    drive_service = build('drive', 'v3', credentials=creds)
    docs_service = build('docs', 'v1', credentials=creds)
    
    return drive_service, docs_service

def find_markdown_files(drive_service):
    """Find all markdown files uploaded today"""
    # Search for .md files
    query = "name contains '2025-11-23' and (name contains '.md' or mimeType = 'text/markdown')"
    
    results = drive_service.files().list(
        q=query,
        spaces='drive',
        fields='files(id, name, parents, mimeType, webViewLink)',
        pageSize=50
    ).execute()
    
    files = results.get('files', [])
    
    # Also search by mimeType
    query2 = "mimeType = 'text/markdown' or mimeType = 'text/x-markdown'"
    results2 = drive_service.files().list(
        q=query2,
        spaces='drive',
        fields='files(id, name, parents, mimeType, webViewLink)',
        pageSize=50
    ).execute()
    
    files.extend(results2.get('files', []))
    
    # Remove duplicates
    seen = set()
    unique_files = []
    for f in files:
        if f['id'] not in seen:
            seen.add(f['id'])
            unique_files.append(f)
    
    return unique_files

def download_file_content(drive_service, file_id):
    """Download the content of a file"""
    request = drive_service.files().get_media(fileId=file_id)
    fh = io.BytesIO()
    downloader = MediaIoBaseDownload(fh, request)
    
    done = False
    while done is False:
        status, done = downloader.next_chunk()
    
    return fh.getvalue().decode('utf-8')

def create_google_doc(docs_service, drive_service, title, content, parent_folder):
    """Create a new Google Doc with the markdown content"""
    # Create new document
    doc = docs_service.documents().create(body={'title': title}).execute()
    doc_id = doc['documentId']
    
    # Insert content
    requests = [
        {
            'insertText': {
                'location': {'index': 1},
                'text': content
            }
        }
    ]
    
    docs_service.documents().batchUpdate(
        documentId=doc_id,
        body={'requests': requests}
    ).execute()
    
    # Move to same folder as original
    if parent_folder:
        drive_service.files().update(
            fileId=doc_id,
            addParents=parent_folder,
            removeParents='root',
            fields='id, parents'
        ).execute()
    
    # Get the web link
    file = drive_service.files().get(
        fileId=doc_id,
        fields='webViewLink'
    ).execute()
    
    return doc_id, file.get('webViewLink')

def convert_file(drive_service, docs_service, file_info):
    """Convert a single markdown file to Google Doc"""
    file_id = file_info['id']
    file_name = file_info['name']
    parent_folder = file_info.get('parents', [None])[0]
    
    print(f"\n📄 Processing: {file_name}")
    
    # Download content
    try:
        content = download_file_content(drive_service, file_id)
        print(f"   ✅ Downloaded ({len(content)} bytes)")
    except Exception as e:
        print(f"   ❌ Error downloading: {str(e)}")
        return False
    
    # Create Google Doc
    doc_title = file_name.replace('.md', '')
    
    try:
        doc_id, web_link = create_google_doc(
            docs_service, 
            drive_service, 
            doc_title, 
            content, 
            parent_folder
        )
        print(f"   ✅ Converted to Google Doc")
        print(f"   🔗 {web_link}")
        return True
    except Exception as e:
        print(f"   ❌ Error creating Doc: {str(e)}")
        return False

def main():
    """Main conversion routine"""
    print("=" * 70)
    print("MARKDOWN TO GOOGLE DOCS CONVERTER")
    print("=" * 70)
    print()
    
    # Initialize services
    drive_service, docs_service = get_services()
    if not drive_service or not docs_service:
        return
    
    # Find markdown files
    print("🔍 Searching for markdown files...")
    md_files = find_markdown_files(drive_service)
    
    if not md_files:
        print("⚠️  No markdown files found")
        return
    
    print(f"📋 Found {len(md_files)} markdown file(s)")
    
    # Convert each file
    print("\n" + "=" * 70)
    print("CONVERTING FILES")
    print("=" * 70)
    
    success_count = 0
    fail_count = 0
    
    for file_info in md_files:
        if convert_file(drive_service, docs_service, file_info):
            success_count += 1
        else:
            fail_count += 1
    
    # Summary
    print("\n" + "=" * 70)
    print("CONVERSION COMPLETE")
    print(f"  ✅ Successfully converted: {success_count}")
    print(f"  ❌ Failed: {fail_count}")
    print("=" * 70)

if __name__ == "__main__":
    main()
