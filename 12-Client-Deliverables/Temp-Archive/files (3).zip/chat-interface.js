/* ===================================
   CLAUDE CHAT INTERFACE - MAIN LOGIC
   ================================== */

class ClaudeChatInterface {
    constructor() {
        this.messages = [];
        this.isExpanded = false;
        this.isStreaming = false;
        this.apiKey = null;
        this.sessionContext = null;
        
        this.init();
    }
    
    async init() {
        // Load API key
        await this.loadApiKey();
        
        // Set up event listeners
        this.setupEventListeners();
        
        // Load session context (MASTER documents)
        await this.loadSessionContext();
        
        console.log('Claude Chat Interface initialized');
    }
    
    async loadApiKey() {
        try {
            const keyPath = 'G:\\My Drive\\00 - Trajanus USA\\00-Command-Center\\Credentials\\Trajanus Command Center api key.txt';
            const result = await window.electronAPI.runCommand(`type "${keyPath}"`);
            this.apiKey = result.stdout.trim();
            this.updateConnectionStatus(true);
        } catch (error) {
            console.error('Failed to load API key:', error);
            this.updateConnectionStatus(false);
            this.showError('Failed to load API credentials');
        }
    }
    
    async loadSessionContext() {
        // This will load the 4 MASTER documents as context
        // For now, placeholder - we'll implement this next
        console.log('Session context loading...');
    }
    
    setupEventListeners() {
        // Toggle chat panel
        document.querySelector('.chat-header').addEventListener('click', (e) => {
            if (!e.target.closest('.chat-header-btn')) {
                this.toggleChat();
            }
        });
        
        // Send message on button click
        document.querySelector('.chat-send-btn').addEventListener('click', () => {
            this.sendMessage();
        });
        
        // Send message on Enter (Shift+Enter for new line)
        document.querySelector('.chat-input').addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });
        
        // Auto-resize textarea
        document.querySelector('.chat-input').addEventListener('input', (e) => {
            e.target.style.height = 'auto';
            e.target.style.height = Math.min(e.target.scrollHeight, 120) + 'px';
        });
        
        // Clear chat
        document.querySelector('[data-action="clear"]').addEventListener('click', () => {
            this.clearChat();
        });
    }
    
    toggleChat() {
        this.isExpanded = !this.isExpanded;
        document.querySelector('.chat-panel').classList.toggle('expanded', this.isExpanded);
        
        if (this.isExpanded && this.messages.length === 0) {
            // Show welcome message on first open
            this.renderWelcome();
        }
    }
    
    updateConnectionStatus(connected) {
        const statusEl = document.querySelector('.chat-status');
        if (connected) {
            statusEl.textContent = 'Connected';
            statusEl.classList.add('connected');
        } else {
            statusEl.textContent = 'Disconnected';
            statusEl.classList.remove('connected');
        }
    }
    
    showError(message) {
        const errorEl = document.querySelector('.chat-error');
        errorEl.textContent = message;
        errorEl.classList.add('active');
        setTimeout(() => errorEl.classList.remove('active'), 5000);
    }
    
    async sendMessage() {
        const input = document.querySelector('.chat-input');
        const message = input.value.trim();
        
        if (!message || this.isStreaming) return;
        
        // Add user message to UI
        this.addMessage('user', message);
        input.value = '';
        input.style.height = 'auto';
        
        // Show typing indicator
        this.showTyping(true);
        
        try {
            // Call Claude API
            const response = await this.callClaudeAPI(message);
            
            // Hide typing indicator
            this.showTyping(false);
            
            // Add Claude's response
            this.addMessage('assistant', response);
            
        } catch (error) {
            this.showTyping(false);
            this.showError('Failed to get response: ' + error.message);
            console.error('API call failed:', error);
        }
    }
    
    async callClaudeAPI(userMessage) {
        if (!this.apiKey) {
            throw new Error('API key not loaded');
        }
        
        this.isStreaming = true;
        document.querySelector('.chat-send-btn').disabled = true;
        
        try {
            // Build messages array with conversation history
            const messages = this.messages
                .filter(m => m.role === 'user' || m.role === 'assistant')
                .map(m => ({
                    role: m.role,
                    content: m.content
                }));
            
            // Add new message
            messages.push({
                role: 'user',
                content: userMessage
            });
            
            // Make API request using Node.js https module
            const requestData = {
                model: 'claude-sonnet-4-20250514',
                max_tokens: 4096,
                messages: messages
            };
            
            const response = await fetch('https://api.anthropic.com/v1/messages', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'x-api-key': this.apiKey,
                    'anthropic-version': '2023-06-01'
                },
                body: JSON.stringify(requestData)
            });
            
            if (!response.ok) {
                throw new Error(`API returned ${response.status}`);
            }
            
            const data = await response.json();
            
            // Update token counter
            this.updateTokenCounter(data.usage);
            
            // Return Claude's response
            return data.content[0].text;
            
        } finally {
            this.isStreaming = false;
            document.querySelector('.chat-send-btn').disabled = false;
        }
    }
    
    addMessage(role, content) {
        const message = {
            role: role,
            content: content,
            timestamp: new Date()
        };
        
        this.messages.push(message);
        this.renderMessage(message);
        
        // Scroll to bottom
        const messagesContainer = document.querySelector('.chat-messages');
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
    
    renderMessage(message) {
        const messagesContainer = document.querySelector('.chat-messages');
        
        // Remove welcome message if present
        const welcome = messagesContainer.querySelector('.chat-welcome');
        if (welcome) welcome.remove();
        
        const messageEl = document.createElement('div');
        messageEl.className = `chat-message ${message.role}`;
        
        const avatar = message.role === 'user' ? 'BK' : 'AI';
        const time = message.timestamp.toLocaleTimeString('en-US', { 
            hour: 'numeric', 
            minute: '2-digit' 
        });
        
        messageEl.innerHTML = `
            <div class="chat-message-avatar">${avatar}</div>
            <div class="chat-message-content">
                <div class="chat-message-text">${this.formatMessage(message.content)}</div>
                <div class="chat-message-time">${time}</div>
            </div>
        `;
        
        messagesContainer.appendChild(messageEl);
    }
    
    formatMessage(text) {
        // Basic markdown-like formatting
        return text
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            .replace(/`(.*?)`/g, '<code>$1</code>')
            .replace(/\n/g, '<br>');
    }
    
    renderWelcome() {
        const messagesContainer = document.querySelector('.chat-messages');
        messagesContainer.innerHTML = `
            <div class="chat-welcome">
                <i class="fas fa-robot"></i>
                <h4>Claude Ready</h4>
                <p>I'm fully integrated into Command Center.<br>
                Ask me anything, and I'll help you manage your projects.</p>
            </div>
        `;
    }
    
    showTyping(show) {
        const indicator = document.querySelector('.typing-indicator');
        if (show) {
            indicator.classList.add('active');
            const messagesContainer = document.querySelector('.chat-messages');
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        } else {
            indicator.classList.remove('active');
        }
    }
    
    updateTokenCounter(usage) {
        const counterEl = document.querySelector('.chat-token-counter');
        const input = usage.input_tokens;
        const output = usage.output_tokens;
        const total = input + output;
        
        // Calculate rough percentage (assuming 200k context window)
        const percentage = Math.round((total / 200000) * 100);
        
        let gauge = '🟢';
        if (percentage > 75) gauge = '🔴';
        else if (percentage > 50) gauge = '🟡';
        
        counterEl.innerHTML = `
            Tokens: ${input.toLocaleString()} in / ${output.toLocaleString()} out
            <span class="token-gauge">${gauge} ${percentage}%</span>
        `;
    }
    
    clearChat() {
        if (confirm('Clear all messages? This cannot be undone.')) {
            this.messages = [];
            this.renderWelcome();
        }
    }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.claudeChat = new ClaudeChatInterface();
});
